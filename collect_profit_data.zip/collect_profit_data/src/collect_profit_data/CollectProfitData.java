package collect_profit_data;
import java.util.*;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;

public class CollectProfitData {
	
	private static final String NEW_LINE_SEPARATOR = "\n";
	private static final String FILE_PATH = "/home/sleviim/Workspaces/PineApple/data/campaigns_profitability.csv";

	private static final String CAMP_PROF_HEADER = "cid,#sim,day,budget,start,end,vidCoeff,mobCoeff,reach,demand,publisher,OML,OMH,OFL,OFH,YML,YMH,YFL,YFH,completion_percentage,profit,decision,revenue,budgetMillis,tartgetedImps,other,cost,ERR";
	//	places in array:							0	1	 2	 	3	 4		5	6		7		8		9		10		11	12	13	14	15	16	17	18			19				20		21		22		23				24		25		26	27

	// *** TO BE REMOVED ****
	///home/sleviim/Workspaces/PineApple/data/campaigns_profitability.csv
	///home/sleviim/Documents/university/sadna/sadna_workspace/adx-server/logs/logs
	
	// 17/03 14:06:30 FINE agents.DemandAgent|Day 3 :Reporting campaign auction results... CampaignImpl [id=1833475304, reachImps=15264, dayStart=4, dayEnd=8, targetSegment=[LOW_INCOME, YOUNG], videoCoef=2.9013056762435143, mobileCoef=2.410690854905925, budgetMillis=2256, advertiser=DummyAdnetwork-4]
	
	// 17/03 14:08:50 INFO demand.CampaignImpl|Campaign 426432094 ended for advertiser DummyAdnetwork-2. Stats CampaignStats [tartgetedImps=3965.128495595574, otherImps=0.0, cost=0.0] Reach 1980 ERR 1.2895716727547863 Budget 0.725 Revenue 0.9349394627472201

	static Scanner reader=new Scanner(System.in);
	
	public static void main(String[] args) throws IOException {
		System.out.println ("Generating statistics from server: Enter the 'from' simulation number:");
		int from = reader.nextInt();
		System.out.println ("Generating statistics from server: Enter the 'to' simulation number:");
		int to = reader.nextInt();
		System.out.println ("Generating statistics from server: Enter the path for the simulation log files (on server)");
		String logPath = reader.next();
	
		FileWriter fileWriter = null;
		HashMap<String, CampaignStatus> dict = new HashMap<String,CampaignStatus>();
		
		try {
			fileWriter = new FileWriter(FILE_PATH, false);
			
			fileWriter.append(CAMP_PROF_HEADER);
			fileWriter.append(NEW_LINE_SEPARATOR);
		}
		catch (Exception e) {
			System.out.println("Error in CsvFileWriter !!!");
			e.printStackTrace();
		}
		
		String currDay= null;
		String[] tmpStringArr;
		CampaignStatus camp;
		
		
		for(int i = from; i<=to; i++){
			String currSim = logPath +"/localhost_SIM_"+ Integer.toString(i)+ ".log";
			File readFromFile = new File(currSim);
			
			try(BufferedReader br = new BufferedReader(new FileReader(readFromFile))) {
				String line;
			    while ((line = br.readLine()) != null) {
			    	if (line.contains("INFO sim.Simulation|***** START OF TIME") && !line.contains("COMPLETE")) {
			    		currDay = line.split("START OF TIME | \\*\\*\\*")[1];
			    	}
			    	else if (line.contains("Reporting campaign auction results... CampaignImpl")|| line.contains("Allocating initial campaign")) {
			    		tmpStringArr = line.split("CampaignImpl \\[id=|, reachImps=|, dayStart=|, dayEnd=|, targetSegment=\\[|\\], videoCoef=|, mobileCoef=|, budgetMillis=|, advertiser=|\\]");
			    		camp = new CampaignStatus();
			    		camp.setGame(i);
			    		camp.setCid(tmpStringArr[1]);
			    		camp.setDay(currDay);
			    		
			    		camp.setBudgetMillis(tmpStringArr[8]);
			    		camp.setStart(tmpStringArr[3]);
			    		camp.setEnd(tmpStringArr[4]);
			    		camp.setVidCoeff(tmpStringArr[6]);
			    		camp.setMobCoeff(tmpStringArr[7]);
			    		camp.setReach(tmpStringArr[2]);
			    		camp.setSegments(tmpStringArr[5]);
			    		
			    		dict.put(tmpStringArr[1], camp);
			    	}
			    	else if (line.contains("ended for advertiser")) {
			    		tmpStringArr = line.split("Campaign | ended|tartgetedImps=|, otherImps=|, cost=|\\] Reach | ERR | Budget | Revenue ");
			    		
			    		camp = dict.get(tmpStringArr[1]);
			    		camp.setBudget(tmpStringArr[8]);
			    		camp.setTartgetedImps(tmpStringArr[3]);
			    		camp.setOther(tmpStringArr[4]);
			    		camp.setCost(tmpStringArr[5]);
			    		camp.setERR(tmpStringArr[7]);
			    		camp.setRevenue(tmpStringArr[9]);
			    		
			    		try {
			    			fileWriter.append(camp.createLine());
			    			fileWriter.append(NEW_LINE_SEPARATOR);
			    		}
			    		catch (Exception e) {
			    			System.out.println("Error in CsvFileWriter !!!");
			    			e.printStackTrace();
			    		}
			    	}
			    }
			    br.close();	
			}
			catch (IOException e) {
				continue;
			}
		}
		
		try {
			fileWriter.flush();
			fileWriter.close();
		}
		catch (IOException e) {
			System.out.println("Error while flushing/closing fileWriter !!!");
			e.printStackTrace();
		}
	}
}
