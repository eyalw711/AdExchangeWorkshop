package tau.tac.adx.agents;

import java.util.ArrayList;
//import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.PrintWriter;

import se.sics.isl.transport.Transportable;
import se.sics.tasim.aw.Agent;
import se.sics.tasim.aw.Message;
import se.sics.tasim.props.SimulationStatus;
import se.sics.tasim.props.StartInfo;

import tau.tac.adx.ads.properties.AdType;
import tau.tac.adx.demand.CampaignStats;
import tau.tac.adx.devices.Device;
import tau.tac.adx.props.AdxBidBundle;
import tau.tac.adx.props.AdxQuery;
import tau.tac.adx.props.PublisherCatalog;
import tau.tac.adx.props.PublisherCatalogEntry;
import tau.tac.adx.props.ReservePriceInfo;
import tau.tac.adx.report.adn.AdNetworkReport;
import tau.tac.adx.report.adn.MarketSegment;
import tau.tac.adx.report.demand.AdNetBidMessage;
import tau.tac.adx.report.demand.AdNetworkDailyNotification;
import tau.tac.adx.report.demand.CampaignOpportunityMessage;
import tau.tac.adx.report.demand.CampaignReport;
import tau.tac.adx.report.demand.CampaignReportKey;
import tau.tac.adx.report.demand.InitialCampaignMessage;
import tau.tac.adx.report.demand.campaign.auction.CampaignAuctionReport;
import tau.tac.adx.report.demand.campaign.auction.CampaignAuctionReportEntry;
import tau.tac.adx.report.publisher.AdxPublisherReport;
import tau.tac.adx.report.publisher.AdxPublisherReportEntry;
import tau.tac.adx.agents.gameStatus.CampaignGameStatus;
import tau.tac.adx.agents.gameStatus.QualityRateGameStatus;
import tau.tac.adx.agents.gameStatus.UCSGameStatus;
import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;
import tau.tac.adx.agents.strategy.BidBundleAggressive;
//import tau.tac.adx.agents.strategy.UCSBidSimple;
import tau.tac.adx.agents.strategy.AbstBidBundleStrategy;
import tau.tac.adx.agents.strategy.AbstCampaignBidStratrgy;
import tau.tac.adx.agents.strategy.BidBundleMinExpenses;
import tau.tac.adx.agents.strategy.CampaignBidAvoidCompetition;
//import tau.tac.adx.agents.strategy.CampaignBidAvoidCompetition;
import tau.tac.adx.agents.strategy.UCSTarget;
import tau.tac.adx.agents.utils.CampaignBidUtils;
//import tau.tac.adx.agents.strategy.UCSBidCustom;
import tau.tac.adx.agents.strategy.UCSBidLearning;
import tau.tac.adx.agents.strategy.CampaignBidHigh;
import tau.tac.adx.agents.strategy.CampaignBidLow;
import tau.tac.adx.agents.strategy.CampaignBidSmallProfit;
//import tau.tac.adx.agents.strategy.UCSBidRegression;
import tau.tac.adx.agents.strategy.AbstUCSBidStrategy;

import edu.umich.eecs.tac.props.Ad;
import edu.umich.eecs.tac.props.BankStatus;


public class AdXperts extends Agent {
  
	private final Logger log = Logger
			.getLogger(AdXperts.class.getName());

	/*
	 * Basic simulation information. An agent should receive the {@link
	 * StartInfo} at the beginning of the game or during recovery.
	 */
	@SuppressWarnings("unused")
	private StartInfo startInfo;

	/**
	 * Messages received:
	 * 
	 * We keep all the {@link CampaignReport campaign reports} delivered to the
	 * agent. We also keep the initialization messages {@link PublisherCatalog}
	 * and {@link InitialCampaignMessage} and the most recent messages and
	 * reports {@link CampaignOpportunityMessage}, {@link CampaignReport}, and
	 * {@link AdNetworkDailyNotification}.
	 */
	private final Queue<CampaignReport> campaignReports = new LinkedList<CampaignReport>();
	private PublisherCatalog publisherCatalog;
	private InitialCampaignMessage initialCampaignMessage;
	private AdNetworkDailyNotification adNetworkDailyNotification;

	/*
	 * The addresses of server entities to which the agent should send the daily
	 * bids data
	 */
	private String demandAgentAddress;
	private String adxAgentAddress;

	/*
	 * we maintain a list of queries - each characterized by the web site (the
	 * publisher), the device type, the ad type, and the user market segment
	 */
	private AdxQuery[] queries;

	/**
	 * Information regarding the latest campaign opportunity announced
	 */
	private CampaignData pendingCampaign;

	/**
	 * We maintain a collection (mapped by the campaign id) of the campaigns won
	 * by our agent.
	 */
	private Map<Integer, CampaignData> myCampaigns;

	/*
	 * the bidBundle to be sent daily to the AdX
	 */
	private AdxBidBundle bidBundle;

	/*
	 * The current bid level for the user classification service
	 */
	private double ucsBid;

	/*
	 * The targeted service level for the user classification service
	 */
	private double ucsTargetLevel;

	/*
	 * current day of simulation
	 */
	private int day;
	private String[] publisherNames;
	private CampaignData currCampaign;
  
	private static SimulationStats sim_stats = new SimulationStats(0);
	
	
  public AdXperts() {
  }
  
  @Override
  protected void messageReceived(Message message) {
	  try {
		  Transportable content = message.getContent();
		  
		  // log.fine(message.getContent().getClass().toString());
		  
		  if (content instanceof InitialCampaignMessage) {
			  handleInitialCampaignMessage((InitialCampaignMessage) content);
		  } else if (content instanceof CampaignOpportunityMessage) {
			  handleICampaignOpportunityMessage((CampaignOpportunityMessage) content);
		  } else if (content instanceof CampaignReport) {
			  handleCampaignReport((CampaignReport) content);
		  } else if (content instanceof AdNetworkDailyNotification) {
			  handleAdNetworkDailyNotification((AdNetworkDailyNotification) content);
		  } else if (content instanceof AdxPublisherReport) {
			  handleAdxPublisherReport((AdxPublisherReport) content);
		  } else if (content instanceof SimulationStatus) {
			  handleSimulationStatus((SimulationStatus) content);
		  } else if (content instanceof PublisherCatalog) {
			  handlePublisherCatalog((PublisherCatalog) content);
		  } else if (content instanceof AdNetworkReport) {
			  handleAdNetworkReport((AdNetworkReport) content);
		  } else if (content instanceof StartInfo) {
			  handleStartInfo((StartInfo) content);
		  } else if (content instanceof BankStatus) {
			  handleBankStatus((BankStatus) content);
		  } else if(content instanceof CampaignAuctionReport) {
			  hadnleCampaignAuctionReport((CampaignAuctionReport) content);
		  } else if (content instanceof ReservePriceInfo) {
			  // ((ReservePriceInfo)content).getReservePriceType();
		  } else {
			  System.out.println("UNKNOWN Message Received: " + content);
			  }

		} catch (NullPointerException e) {
			this.log.log(Level.SEVERE,
					"Exception thrown while trying to parse message." + e);
			return;
		}
	}
  
  private void hadnleCampaignAuctionReport(CampaignAuctionReport content) {
    log.info("Day: " + day);
    log.info("Winner: " + content.getWinner());
    log.info("Campaign report: " + content.toString());

    if (day > 1) {
      double price = Double.MAX_VALUE;
      for (int i = 0; i < content.size(); i++) {
        CampaignAuctionReportEntry entry = (CampaignAuctionReportEntry)content.getEntry(i);
        if (entry.getActualBid() < price) {
          price = entry.getActualBid();
        }
      }
      ((CampaignGameStatus.CampaignStatus)sim_stats
    		  .getCampaignStatus().getRecords(day - 1)).setPrice(price);
      ((CampaignGameStatus.CampaignStatus)sim_stats
    		  .getCampaignStatus().getRecords(day - 1)).setAuctionReport(content);
    }
  }
  
  private void handleBankStatus(BankStatus content) {
    System.out.println("Day " + day + " :" + content.toString());
  }
  
  /**
   * Processes the start information.
   * 
   * @param startInfo
   *            the start information.
   */
  protected void handleStartInfo(StartInfo startInfo) {
    this.startInfo = startInfo;
  }
  
  /**
   * Process the reported set of publishers
   * 
   * @param publisherCatalog
   */
  private void handlePublisherCatalog(PublisherCatalog publisherCatalog) {
    this.publisherCatalog = publisherCatalog;
    generateAdxQuerySpace();
    getPublishersNames();
  }
  
  /**
   * On day 0, a campaign (the "initial campaign") is allocated to each
   * competing agent. The campaign starts on day 1. The address of the
   * server's AdxAgent (to which bid bundles are sent) and DemandAgent (to
   * which bids regarding campaign opportunities may be sent in subsequent
   * days) are also reported in the initial campaign message
   */
  private void handleInitialCampaignMessage(InitialCampaignMessage campaignMessage) {
	System.out.println(campaignMessage.toString());
    
    day = 0;
    sim_stats.setDay(day);
    
    initialCampaignMessage = campaignMessage;
    demandAgentAddress = campaignMessage.getDemandAgentAddress();
    adxAgentAddress = campaignMessage.getAdxAgentAddress();
    
    CampaignData campaignData = new CampaignData(initialCampaignMessage);
    campaignData.setBudget(initialCampaignMessage.getBudgetMillis()/1000.0);
    currCampaign = campaignData;
    genCampaignQueries(currCampaign);
    
    /*
	 * The initial campaign is already allocated to our agent so we add it
	 * to our allocated-campaigns list.
	 */
	System.out.println("Day " + day + ": Allocated campaign - " + campaignData);
    myCampaigns.put(Integer.valueOf(initialCampaignMessage.getId()), campaignData);
  }
  
  /**
   * On day n ( > 0) a campaign opportunity is announced to the competing
   * agents. The campaign starts on day n + 2 or later and the agents may send
   * (on day n) related bids (attempting to win the campaign). The allocation
   * (the winner) is announced to the competing agents during day n + 1.
   */
  private void handleICampaignOpportunityMessage(CampaignOpportunityMessage com) {
    day = com.getDay();
    
    sim_stats.setDay(day);
    
    pendingCampaign = new CampaignData(com);
    System.out.println("Day " + day + ": Campaign opportunity - " + pendingCampaign);
    
    double quality_rate;
    if (sim_stats.getQualityRatingDataHistory().getRecords(sim_stats.getDay()) != null) {
    	quality_rate = ((QualityRateGameStatus.QualityRateStatus)sim_stats
    			.getQualityRatingDataHistory().getRecords(sim_stats.getDay())).getQualityRate();
    }
    else {quality_rate = 1.0;}
    
    /*
	 * The campaign requires com.getReachImps() impressions. The competing
	 * Ad Networks bid for the total campaign Budget (that is, the ad
	 * network that offers the lowest budget gets the campaign allocated).
	 * The advertiser is willing to pay the AdNetwork at most 1$ CPM,
	 * therefore the total number of impressions may be treated as a reserve
	 * (upper bound) price for the auction.
	 */

    UCSTarget UCS_costEfficient = new UCSTarget(sim_stats);
	
    double campaign_length = pendingCampaign.getDayEnd() - (pendingCampaign.getDayStart());
    
    //determine campaign bid strategy
    AbstCampaignBidStratrgy bid_strategy = setBidStrategy (campaign_length, quality_rate);
    
    //consider changing the bid strategy
    bid_strategy = changeBidStrategy(bid_strategy);
    
    long campaign_bid = bid_strategy.getCampaignBid(pendingCampaign);
    
    log.info("Strategy being used :" + bid_strategy.getStrategyName());
    log.info("Opportunity Campaign bid: " + campaign_bid);
    
    
    //determine USC bid strategy
    ucsTargetLevel = UCS_costEfficient.getUCSTarget();
    
    if (day==0) {log.info("Initial ucs bid: " + ucsBid);}
    else {
    	AbstUCSBidStrategy ucsBidStrategy =
    			setUCSStrategy(ucsBid, adNetworkDailyNotification.getServiceLevel());
    	ucsBid = ucsBidStrategy.getUCSBid(ucsTargetLevel);
    }
    log.info("UCS target level: " + ucsTargetLevel);
    log.info("UCS bid: " + ucsBid);
    
    //record game
    sim_stats.getUCSStatus().record(day, 0.0, 0.0);
    sim_stats.getCampaignStatus().record(day, pendingCampaign);
    ((CampaignGameStatus.CampaignStatus)sim_stats.getCampaignStatus()
    		.getRecords(day)).setOurBid(campaign_bid);
    ((CampaignGameStatus.CampaignStatus)sim_stats.getCampaignStatus()
    		.getRecords(day)).setBidParametersString(bid_strategy.bidToString());
    
    //Send campaign and UCS bids
    AdNetBidMessage bids = new AdNetBidMessage(ucsBid, pendingCampaign.id, Long.valueOf(campaign_bid));
    sendMessage(demandAgentAddress, bids);
  }
  
  /**
   * On day n ( > 0), the result of the UserClassificationService and Campaign
   * auctions (for which the competing agents sent bids during day n -1) are
   * reported. The reported Campaign starts in day n+1 or later and the user
   * classification service level is applicable starting from day n+1.
   */
  private void handleAdNetworkDailyNotification(AdNetworkDailyNotification notificationMessage) {
    adNetworkDailyNotification = notificationMessage;
    
    System.out.println("Day " + day + ": Daily notification for campaign "
			+ adNetworkDailyNotification.getCampaignId());
    
    String campaignAllocatedTo = " allocated to " + 
      notificationMessage.getWinner();
    
    CampaignGameStatus.CampaignStatus campaignReportPrev =
    		(CampaignGameStatus.CampaignStatus)sim_stats
    		.getCampaignStatus().getRecords(day - 1);
    
    if ((pendingCampaign.id == adNetworkDailyNotification.getCampaignId()) && 
      (notificationMessage.getCostMillis() != 0)) {
    	
      /* add campaign to list of won campaigns */
      pendingCampaign.setBudget(notificationMessage.getCostMillis() / 1000.0);
      currCampaign = pendingCampaign;
      genCampaignQueries(currCampaign);
      myCampaigns.put(pendingCampaign.id, pendingCampaign);
      
      if (campaignReportPrev != null) {
        campaignReportPrev.setWon(true);
        campaignReportPrev.setPrice(notificationMessage.getCostMillis() / 1000.0);
      }
      
      campaignAllocatedTo = 
        " WON at cost " + notificationMessage.getCostMillis() / 1000;
    }
    
    System.out.println("Day " + day + ": " + campaignAllocatedTo + "\n"
			+ ". UCS Level set to " + notificationMessage.getServiceLevel()
			+ " at price " + notificationMessage.getPrice()
			+ " Quality Score is: " + notificationMessage.getQualityScore());
    
    sim_stats.getQualityRatingDataHistory().record(day, notificationMessage.getQualityScore());
    if (sim_stats.getUCSStatus().getRecords(day - 1) != null) {
      ((UCSGameStatus.UCSStatus)sim_stats.getUCSStatus().getRecords(day - 1)).level =
    		  notificationMessage.getServiceLevel();
      ((UCSGameStatus.UCSStatus)sim_stats.getUCSStatus().getRecords(day - 1)).price =
    		  notificationMessage.getPrice();
    }
  }

  /**
   * The SimulationStatus message received on day n indicates that the
   * calculation time is up and the agent is requested to send its bid bundle
   * to the AdX.
   */
  private void handleSimulationStatus(SimulationStatus simulationStatus) {
    System.out.println("Day " + day + " : Simulation Status Received");
	sendBidAndAds();
	System.out.println("Day " + day + " ended. Starting next day");
	++day;
  }
  
  protected void sendBidAndAds() {
      
    bidBundle = new AdxBidBundle();
	int dayBiddingFor = day + 1;
	
	for (CampaignData campaign : myCampaigns.values()) {
		
		AbstBidBundleStrategy bidBundleStrategy = setBidBundleStrategy(campaign);
		double rbid = bidBundleStrategy.getBid(campaign);
		
		/*
		 * add bid entries w.r.t. each active campaign with remaining contracted
		 * impressions.
		 * 
		 * for now, a single entry per active campaign is added for queries of
		 * matching target segment.
		 */
	    if ((dayBiddingFor >= campaign.getDayStart())
				&& (dayBiddingFor <= campaign.getDayEnd())
				&& (campaign.impsTogo() > 0)) {
	
			int entCount = 0;
	
			for (AdxQuery query : campaign.campaignQueries) {
				if (campaign.impsTogo() - entCount > 0) {
					/*
					 * among matching entries with the same campaign id, the AdX
					 * randomly chooses an entry according to the designated
					 * weight. by setting a constant weight 1, we create a
					 * uniform probability over active campaigns(irrelevant because we are bidding only on one campaign)
					 */
					if (query.getDevice() == Device.pc) {
						if (query.getAdType() == AdType.text) {
							entCount++;
						} else {
							entCount += campaign.getVideoCoef();
						}
					} else {
						if (query.getAdType() == AdType.text) {
							entCount+=campaign.getMobileCoef();
						} else {
							entCount += campaign.getVideoCoef() + campaign.getMobileCoef();
						}
					}
					
					bidBundle.addQuery(query, rbid, new Ad(null), campaign.id,
							bidBundleStrategy.getFactorAccordingToDaysLeftForCampaign(campaign));
				}
			}
	
			double impressionLimit = campaign.impsTogo();
			double budgetLimit = campaign.getBudget();
			bidBundle.setCampaignDailyLimit(campaign.id,
					(int) impressionLimit, budgetLimit);
	
			System.out.println("Day " + day + ": Updated " + entCount
					+ " Bid Bundle entries for Campaign id " + campaign.id);
		}
	}
    
    if (bidBundle != null) {
    	System.out.println("Day " + day + ": Sending BidBundle");
		sendMessage(adxAgentAddress, bidBundle);
    }
  }
  
  /**
   * Campaigns performance w.r.t. each allocated campaign
   */
  private void handleCampaignReport(CampaignReport campaignReport) {
	  
    campaignReports.add(campaignReport);
    
    /*
	 * for each campaign, the accumulated statistics from day 1 up to day
	 * n-1 are reported
	 */
    for (CampaignReportKey campaignKey : campaignReport.keys()) {
      int cmpId = campaignKey.getCampaignId().intValue();
      CampaignStats cstats = campaignReport.getCampaignReportEntry(
        campaignKey).getCampaignStats();
      myCampaigns.get(cmpId).setStats(cstats);
      
      System.out.println("Day " + day + ": Updating campaign " + cmpId + " stats: "
				+ cstats.getTargetedImps() + " tgtImps "
				+ cstats.getOtherImps() + " nonTgtImps. Cost of imps is "
				+ cstats.getCost());
    }
  }
  
  /**
   * Users and Publishers statistics: popularity and ad type orientation
   */
  private void handleAdxPublisherReport(AdxPublisherReport adxPublisherReport) {
	System.out.println("Publishers Report: ");
    for (PublisherCatalogEntry publisherKey : adxPublisherReport.keys()) {
      AdxPublisherReportEntry entry = adxPublisherReport.getEntry(publisherKey);
      System.out.println(entry.toString());
    }
    sim_stats.getPublisherStatus().record(adxPublisherReport, day);
  }
  
  /**
   * 
   * @param AdNetworkReport
   */
  private void handleAdNetworkReport(AdNetworkReport adnetReport) {
    System.out.println("Day " + day + " : AdNetworkReport");
	/*
	 * for (AdNetworkKey adnetKey : adnetReport.keys()) {
	 * 
	 * double rnd = Math.random(); if (rnd > 0.95) { AdNetworkReportEntry
	 * entry = adnetReport .getAdNetworkReportEntry(adnetKey);
	 * System.out.println(adnetKey + " " + entry); } }
	 */
  }
  
  @Override
  protected void simulationSetup() {
    Random random = new Random();
    
    day = 0;
    bidBundle = new AdxBidBundle();

    /* initial bid between 0.1 and 0.2 */
    ucsBid = 0.1 + random.nextDouble()/10.0;
    ucsTargetLevel = 0.6 + random.nextInt(5)/10.0;
    
    myCampaigns = new HashMap<Integer, CampaignData>();
    sim_stats.setOurCampaigns(myCampaigns);
    log.fine("AdNet " + getName() + " simulationSetup");
  }
  
  protected void simulationFinished() {
    try {
      PrintWriter out = new PrintWriter("PastGamesData" + File.separator + "CampaignsGame" + sim_stats.getGameNumber() + ".txt");
      
      out.print("RECORDS:\n");     
      
      out.print("bid for opportunity:\n");
      for (int i = 0; i < sim_stats.getCampaignStatus().getRecordsNum(); i++) {
        if (sim_stats.getCampaignStatus().getRecords(i) != null)
        {
        	CampaignGameStatus.CampaignStatus currCampaignReport =
        			(CampaignGameStatus.CampaignStatus)sim_stats
        			.getCampaignStatus().getRecords(i);
          out.println("Day " + i + ":");
          out.println("Campaign details:" + currCampaignReport.getCampignData().toString());
          out.println("OurBid: " + currCampaignReport.getOurBid());
          out.println("Bid Parameters: "+ currCampaignReport.getBidParametersString());
        }
      }
      
      out.print("Quality rate:\n");
      for (int i = 0; i < sim_stats.getQualityRatingDataHistory().getRecordsNum(); i++) {
        if (sim_stats.getQualityRatingDataHistory().getRecords(i) != null) {
        	QualityRateGameStatus.QualityRateStatus currRating =
        			(QualityRateGameStatus.QualityRateStatus)sim_stats
        			.getQualityRatingDataHistory().getRecords(i);
          out.print(currRating.getQualityRate());
        }
      }
      
      out.close();
    } catch (FileNotFoundException e) {
      e.printStackTrace();
    }
    sim_stats.saveGame();
  }
  
  /*
   * A user visit to a publisher's web-site results in an impression
   * opportunity (a query) that is characterized by the the publisher, the
   * market segment the user may belongs to, the device used (mobile or
   * desktop) and the ad type (text or video).
   * 
   * An array of all possible queries is generated here, based on the
   * publisher names reported at game initialization in the publishers catalog
   * message
   */
  private void generateAdxQuerySpace() {
    if ((publisherCatalog != null) && (queries == null)) {
      Set<AdxQuery> querySet = new HashSet<AdxQuery>();
      
      /*
       * for each web site (publisher) we generate all possible variations
       * of device type, ad type, and user market segment
       */
      for (PublisherCatalogEntry publisherCatalogEntry : publisherCatalog) {
        String publishersName = publisherCatalogEntry
          .getPublisherName();
        for (MarketSegment userSegment : MarketSegment.values()) {
          Set<MarketSegment> singleMarketSegment = new HashSet<MarketSegment>();
          singleMarketSegment.add(userSegment);
          
          querySet.add(new AdxQuery(publishersName, 
            singleMarketSegment, Device.mobile, AdType.text));
          
          querySet.add(new AdxQuery(publishersName, 
            singleMarketSegment, Device.pc, AdType.text));
          
          querySet.add(new AdxQuery(publishersName, 
            singleMarketSegment, Device.mobile, AdType.video));
          
          querySet.add(new AdxQuery(publishersName, 
            singleMarketSegment, Device.pc, AdType.video));
        }
        
        /**
		 * An empty segments set is used to indicate the "UNKNOWN"
		 * segment such queries are matched when the UCS fails to
		 * recover the user's segments.
		 */
        querySet.add(new AdxQuery(publishersName, 
          new HashSet<MarketSegment>(), Device.mobile, 
          AdType.video));
        querySet.add(new AdxQuery(publishersName, 
          new HashSet<MarketSegment>(), Device.mobile, 
          AdType.text));
        querySet.add(new AdxQuery(publishersName, 
          new HashSet<MarketSegment>(), Device.pc, AdType.video));
        querySet.add(new AdxQuery(publishersName,
          new HashSet<MarketSegment>(), Device.pc, AdType.text));
      }
      queries = new AdxQuery[querySet.size()];
      querySet.toArray(queries);
    }
  }
  
  /* 
   * genarates an array of the publishers names
   * */
  private void getPublishersNames() {
	  if (null == publisherNames && publisherCatalog != null) {
		  ArrayList<String> names = new ArrayList<String>();
		  for (PublisherCatalogEntry pce : publisherCatalog) {
			  names.add(pce.getPublisherName());
			  }
		  publisherNames = new String[names.size()];
		  names.toArray(publisherNames);
		  }
	  }
  
  /*
   * genarates the campaign queries relevant for the specific campaign, and assign them as the campaigns campaignQueries field 
   */
  private void genCampaignQueries(CampaignData campaignData)
  {
    Set<AdxQuery> campaignQueriesSet = new HashSet<AdxQuery>();
    for (String PublisherName : publisherNames) {
      campaignQueriesSet.add(new AdxQuery(PublisherName, 
        campaignData.getTargetSegment(), Device.mobile, AdType.text));
      campaignQueriesSet.add(new AdxQuery(PublisherName, 
        campaignData.getTargetSegment(), Device.mobile, AdType.video));
      campaignQueriesSet.add(new AdxQuery(PublisherName, 
        campaignData.getTargetSegment(), Device.pc, AdType.text));
      campaignQueriesSet.add(new AdxQuery(PublisherName, 
        campaignData.getTargetSegment(), Device.pc, AdType.video));
    }
    
    campaignData.setCampaignQueries(campaignQueriesSet.toArray(new AdxQuery[campaignQueriesSet.size()]));
  }

  
  /*
   * function to determine current bid strategy.
   * used in handleICampaignOpportunityMessage
   */
  private AbstCampaignBidStratrgy setBidStrategy (double campaign_length, double quality_rate) {
	  AbstCampaignBidStratrgy min = new CampaignBidLow(sim_stats);
	  AbstCampaignBidStratrgy max = new CampaignBidHigh(sim_stats);
	  AbstCampaignBidStratrgy smallProfit = new CampaignBidSmallProfit(sim_stats);
	  AbstCampaignBidStratrgy avoid_competition = new CampaignBidAvoidCompetition(sim_stats);
	  
	  //Constants
	  final int lateDays = 55;
	  
	  Random random = new Random();
	  double random_probability = random.nextDouble();
	  
	  if(day < lateDays){
		  if(random_probability <= 0.25)
			  return smallProfit;
		  else if(random_probability <= 0.95)
			  return min;
		  else
			  return avoid_competition;
	  }
		  
	  else
		  return max;
  	}

  /*
   * function to change the bid strategy if needed, according to the actual bid.
   * used in handleICampaignOpportunityMessage
   */
  private AbstCampaignBidStratrgy changeBidStrategy (AbstCampaignBidStratrgy bid_strategy) {
	  final int CAMPAIGN_LOOSE_STREAK_BOUND = 4;
	  
	  Random random = new Random();
	  double random_probability = random.nextDouble();
	  
	  //get the campaign bid initially set
	  long bid = bid_strategy.getCampaignBid(pendingCampaign);
	  
	  //if we got a big loose streak for campaigns - bid min
	  CampaignBidUtils util = new CampaignBidUtils(sim_stats);
	  int looseStreak = util.getLoseStreaks(day);
	  if(looseStreak > CAMPAIGN_LOOSE_STREAK_BOUND)
		  return new CampaignBidLow(sim_stats);
	  
	  if (bid < 200) {
	      if (random_probability <= 0.7) {
	    	  return new CampaignBidHigh(sim_stats);
	      }
	    }
	   else if (day > 5) {
	      if (random_probability <= 0.4) {
	    	  return new CampaignBidLow(sim_stats);
	      }
	    }
	  
	  return bid_strategy;   
  }
  
  /*
   * function to determine current USC strategy.
   * used in handleICampaignOpportunityMessage
   */
  private AbstUCSBidStrategy setUCSStrategy(double prev_bid, double level) {
	  sim_stats.setPrevUcsBid(prev_bid);
	  sim_stats.setUcsLevel(level);
	  
	  return (new UCSBidLearning(sim_stats));
  }

  /*
   * function to determine current Bid Bundle strategy.
   * used in sendBidAndAds
   */
  private AbstBidBundleStrategy setBidBundleStrategy(CampaignData campaign){
	  BidBundleAggressive aggressive = new BidBundleAggressive(sim_stats);
      BidBundleMinExpenses minExpenses = new BidBundleMinExpenses(sim_stats);
		
	  double days_left = campaign.getDayEnd() - day;
	  
	  if ((day <= 15) ||
		  (days_left == 1.0) ||
		  ((days_left == 2.0) && (campaign.getDayEnd() - campaign.getDayStart() > 2)) ||
		  ((days_left == 3.0) && (campaign.stats.getCost() < 0.7 * campaign.getBudget()))) {
		  return aggressive;
	  }
	  return minExpenses;  
  }
}
