package tau.tac.adx.agents.gameStatus;

import tau.tac.adx.props.PublisherCatalogEntry;
import tau.tac.adx.report.publisher.AdxPublisherReport;
import tau.tac.adx.report.publisher.AdxPublisherReportEntry;

public class PublisherGameStatus extends GameRecords {
	
  // Method to record the current status
  public void record(AdxPublisherReport publisherReport, int day) {
	CurrentStatus publisher_day_status = new PublisherStatus(publisherReport);
    game_records.put(day, publisher_day_status);
  }
  
  /*
   * Class to hold the current publisher status
   * */
  public static class PublisherStatus implements CurrentStatus {
	  private int publisher_popularity;
	  
	  // Constructor
	  public PublisherStatus(AdxPublisherReport publisher_report) {
		  publisher_popularity = calcPopularity(publisher_report);
	  }
	  
	  // Method to calculate the publisher's popularity by the report
	  private int calcPopularity(AdxPublisherReport publisher_report) {
		  int popularity = 0;
		  for (PublisherCatalogEntry i : publisher_report.keys()) {
			  popularity += ((AdxPublisherReportEntry)publisher_report.getEntry(i)).getPopularity();
		    }
		  return popularity;
	  }
	  
	  /*
	   * publisher_popularity - getter
	   */
	  public int getPopularity() {return publisher_popularity;}
	}
}
