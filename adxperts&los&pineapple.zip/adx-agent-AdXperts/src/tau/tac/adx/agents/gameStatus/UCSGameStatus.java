package tau.tac.adx.agents.gameStatus;

public class UCSGameStatus extends GameRecords{
	
  // Method to record the current status	
  public void record(int day, double UCSLevel, double UCSPrice) {
	CurrentStatus ucs_day_status = new UCSStatus(UCSLevel, UCSPrice);
    game_records.put(day, ucs_day_status);
  }
  
  /*
   * Class to hold the current ucs status
   * */
  public static class UCSStatus implements CurrentStatus {  
	  public double level;
	  public double price;
	  
	  public UCSStatus(double _level, double _price) {
	    level = _level;
	    price = _price;
	  }
	}
}
