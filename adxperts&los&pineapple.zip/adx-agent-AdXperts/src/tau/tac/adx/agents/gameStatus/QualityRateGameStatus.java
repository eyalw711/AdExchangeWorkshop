package tau.tac.adx.agents.gameStatus;

public class QualityRateGameStatus extends GameRecords {
	
  // Method to record the current status
  public void record(int day, double qualityRating) {
	CurrentStatus quality_day_status = new QualityRateStatus(qualityRating);
    game_records.put(day, quality_day_status);
  }
  
  /*
   * Class to hold the current quality status
   * */
  public class QualityRateStatus implements CurrentStatus {
	  private double our_qr;
	  
	  // Constructor
	  public QualityRateStatus(double quality_rate){our_qr = quality_rate;}
	  
	  /*
	   * our_qr - getter
	   */
	  public double getQualityRate() {return our_qr;}
	  
  }
}
