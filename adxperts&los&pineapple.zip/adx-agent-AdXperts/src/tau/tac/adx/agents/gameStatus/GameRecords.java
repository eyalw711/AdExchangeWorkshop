package tau.tac.adx.agents.gameStatus;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

public abstract class GameRecords{
	
  protected Map<Integer, CurrentStatus> game_records
  							= new HashMap<Integer, CurrentStatus>();   // Keeps records of on-going game
  protected Map<Integer, Map<Integer, CurrentStatus>> past_games_records
  							= new HashMap<Integer, Map<Integer, CurrentStatus>>(); // Keeps records of past game
  protected int num_of_game = 0;
  
  // Constructor
  protected GameRecords(){past_games_records.put(num_of_game, game_records);}
  
  // Methods to get details on records
  public int getRecordsNum() {return game_records.size();}
  public int getRecordsNum(int game_num) {return (past_games_records.get(game_num)).size();}  
  public Collection<CurrentStatus> getRecordsValues() {return game_records.values();}
  public CurrentStatus getRecords(int day) {
    if (game_records.containsKey(day)) {
      return (CurrentStatus)game_records.get(day);
    }
    return null;
  }
  public CurrentStatus getRecords(int day, int game_num) {
    return (CurrentStatus)(past_games_records.get(game_num)).get(day);
  }
  
  // Method to save records
  public void saveRecords() {
	num_of_game++;
	game_records = new HashMap<Integer, CurrentStatus>();
	past_games_records.put(num_of_game, this.game_records);
  }
}
