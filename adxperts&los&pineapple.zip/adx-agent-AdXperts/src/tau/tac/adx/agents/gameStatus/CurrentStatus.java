package tau.tac.adx.agents.gameStatus;

public abstract interface CurrentStatus {}