package tau.tac.adx.agents.gameStatus;

import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.report.demand.campaign.auction.CampaignAuctionReport;

public class CampaignGameStatus extends GameRecords {
  
  // Method to record the current status
  public void record(int day, CampaignData Campaign) {
	  CurrentStatus campaign_day_status = new CampaignStatus(Campaign);
	  game_records.put(day, campaign_day_status);
  }
  
  /*
   * Class to hold the current campaign status
   * */
  public static class CampaignStatus implements CurrentStatus {
		
	  private String parameters_of_bid;
	  private double second_bid;
	  private double our_bid;
	  private double our_price;
	  private boolean won;
	  private CampaignAuctionReport auction_report;
	  private CampaignData campaign_data;
	  
	  // Constructor
	  public CampaignStatus(CampaignData _campaign_data) {
	    campaign_data = _campaign_data;
	    our_bid = 0.0;
	    won = false;
	  }
	  
	  /*
	   * parameters_of_bid - setter + getter
	   */
	  public void setBidParametersString(String _parameters_of_bid) {parameters_of_bid = _parameters_of_bid;}
	  public String getBidParametersString() {return this.parameters_of_bid;}
	  
	  /*
	   * second_bid - setter + getter
	   */
	  public void setSecondBid(double _winSecondBid) {second_bid = _winSecondBid;}
	  public double getSecondBid() {return second_bid;}
	  
	  /*
	   * our_bid - setter + getter
	   */
	  public void setOurBid(double _our_bid) {our_bid = _our_bid;}
	  public double getOurBid() {return our_bid;}
	  
	  /*
	   * our_price - setter + getter
	   */
	  public void setPrice(double _our_price){our_price = _our_price;}
	  public double getPrice() {return this.our_price;}
	  
	  /*
	   * won - setter + getter
	   */
	  public void setWon(boolean _won) {won = _won;}
	  public boolean getWon() {return won;}
	  
	  /*
	   * auction_report - setter + getter
	   */
	  public void setAuctionReport(CampaignAuctionReport _auction_report){auction_report = _auction_report;}
	  public CampaignAuctionReport getAuctionReport() {return this.auction_report;}
	  
	  /*
	   * campaign_data - setter + getter
	   */
	  public void setCampignData(CampaignData _campaign_data) {campaign_data = _campaign_data;}
	  public CampaignData getCampignData() {return this.campaign_data;}
	}
}
