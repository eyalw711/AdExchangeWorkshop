package tau.tac.adx.agents.simulation;

import java.util.Set;
import tau.tac.adx.demand.CampaignStats;
import tau.tac.adx.report.adn.MarketSegment;
import tau.tac.adx.report.demand.CampaignOpportunityMessage;
import tau.tac.adx.report.demand.InitialCampaignMessage;
import tau.tac.adx.props.AdxQuery;

public class CampaignData {
	//public Long reachImps;
	public long reachImps;
	private long dayStart;
	private long dayEnd;
	public Set<MarketSegment> targetSegment;
	private double videoCoef;
	private double mobileCoef;
	public int id;
	
	private double budget;
	public CampaignStats stats;
	private double campaignPrice;
	public AdxQuery[] campaignQueries;
		

	public CampaignData(InitialCampaignMessage icm) {
		reachImps = icm.getReachImps();
		dayStart = icm.getDayStart();
		dayEnd = icm.getDayEnd();
		targetSegment = icm.getTargetSegment();
		videoCoef = icm.getVideoCoef();
		mobileCoef = icm.getMobileCoef();
		id = icm.getId();
		campaignPrice = 0.0;
		stats = new CampaignStats(0, 0, 0);
		budget = 0.0;
	}

	public CampaignData(CampaignOpportunityMessage com) {
		dayStart = com.getDayStart();
		dayEnd = com.getDayEnd();
		id = com.getId();
		reachImps = com.getReachImps();
		targetSegment = com.getTargetSegment();
		mobileCoef = com.getMobileCoef();
		videoCoef = com.getVideoCoef();
		stats = new CampaignStats(0, 0, 0);
		budget = 0.0;
	}

	//Setter and Getters
	
	public double getBudget(){
		return budget;
	}
	
	public void setBudget(double _budget) {
		budget = _budget;
	}
	
	public long getDayStart() {
		return dayStart;
	}

	public void setDayStart(long _dayStart) {
		dayStart = _dayStart;
	}

	public long getDayEnd() {
		return dayEnd;
	}

	public void setDayEnd(long _dayEnd) {
		dayEnd = _dayEnd;
	}

	public double getVideoCoef() {
		return videoCoef;
	}

	public void setVideoCoef(double _videoCoef) {
		videoCoef = _videoCoef;
	}

	public double getMobileCoef() {
		return mobileCoef;
	}

	public void setMobileCoef(double _mobileCoef) {
		mobileCoef = _mobileCoef;
	}

	public int getId() {
		return id;
	}

	public void setId(int _id) {
		id = _id;
	}

	public void setStats(CampaignStats _stats) {
		stats.setValues(_stats);
	}
	
	public CampaignStats getStats() {
		return stats;
	}

	public void setCampaignQueries(AdxQuery[] _campaign_queries) {
		campaignQueries = _campaign_queries;
	}
	
	public AdxQuery[] getCampQueries() {
		return campaignQueries;
	}
	
	public double getPaymant() {
		return campaignPrice;
	}

	public void setPaymant(double paymant) {
		this.campaignPrice = paymant;
	}

	public Set<MarketSegment> getTargetSegment() {
		return targetSegment;
	}
	
	public Long getReachImps() {
		return reachImps;
	}

	public void setReachImps(Long reachImps) {
		this.reachImps = reachImps;
	}
	
	
	//==========other functions==========

	public int impsTogo() {
		return (int) (Math.max(0, reachImps - stats.getTargetedImps()));
	}
	
	public String toString() {
		return

		"Campaign ID " + id + ": " + "day " + dayStart + " to " + dayEnd + " " + targetSegment
				+ ", reach: " + reachImps + " coefs: (v=" + videoCoef + ", m=" + mobileCoef + ")";
	}
	
}
