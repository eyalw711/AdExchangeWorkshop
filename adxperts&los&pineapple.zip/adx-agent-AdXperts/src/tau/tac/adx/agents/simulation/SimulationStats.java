package tau.tac.adx.agents.simulation;

import java.util.Collection;
import java.util.HashMap;
import java.util.Map;

import tau.tac.adx.agents.gameStatus.CampaignGameStatus;
import tau.tac.adx.agents.gameStatus.PublisherGameStatus;
import tau.tac.adx.agents.gameStatus.QualityRateGameStatus;
import tau.tac.adx.agents.gameStatus.UCSGameStatus;

public class SimulationStats {
	private CampaignGameStatus campaign_status;
	private UCSGameStatus ucs_status;
	private Map<Integer, CampaignData> our_campaigns;
	private PublisherGameStatus publisher_status;
	private QualityRateGameStatus quality_status;
	private int curr_game;
	private int curr_day;
	private double ucs_level;
	private double prev_ucs_bid;
	

	public SimulationStats(int _day) {
		quality_status = new QualityRateGameStatus();
		ucs_status = new UCSGameStatus();
		our_campaigns = new HashMap<Integer, CampaignData>();
		publisher_status = new PublisherGameStatus();
		campaign_status = new CampaignGameStatus();
		curr_day = _day;
		curr_game = 0;
	}
	
	
	//Getters and Setters	
	public Collection<CampaignData> getOurCampaignsData(){return our_campaigns.values();}
	public void setOurCampaigns(Map<Integer, CampaignData> _myCampaigns) {our_campaigns = _myCampaigns;}
	
	public int getDay() {return curr_day;}
	public void setDay(int _day) {curr_day = _day;}
	public void nextDay(){curr_day++;}
	
	public int getGameNumber() {return curr_game;}
	private void nextGame() {curr_game++;}

	public UCSGameStatus getUCSStatus() {return ucs_status;}
	public double getUcsLevel() {return ucs_level;}
	public void setUcsLevel(double _ucsBid) {ucs_level = _ucsBid;}
	public double getPrevUcsBid() {return prev_ucs_bid;}
	public void setPrevUcsBid(double _prevUcsBid) {prev_ucs_bid = _prevUcsBid;}

	public QualityRateGameStatus getQualityRatingDataHistory() {return quality_status;}
	
	public CampaignGameStatus getCampaignStatus() {return campaign_status;}

	public PublisherGameStatus getPublisherStatus() {return publisher_status;}
	
	public void saveGame() {
		campaign_status.saveRecords();
		quality_status.saveRecords();
		ucs_status.saveRecords();
		
		nextGame();
	}

}
