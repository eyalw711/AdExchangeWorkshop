package tau.tac.adx.agents.strategy;

import java.util.ArrayList;
import java.util.Random;
import java.util.logging.Logger;

import tau.tac.adx.agents.gameStatus.PublisherGameStatus;
import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;
import tau.tac.adx.agents.utils.CampaignBidUtils;
import tau.tac.adx.agents.utils.ImpressionsBidUtils;
import tau.tac.adx.agents.utils.MarketSegmentProbability;
import tau.tac.adx.report.adn.MarketSegment;

public class BidBundleMinExpenses extends AbstBidBundleStrategy {
  
  private int day;
  private CampaignBidUtils campaign_bid_utils;
  private ImpressionsBidUtils impressions_bid_utils;
  private MarketSegmentProbability segment_prob = new MarketSegmentProbability();
  private final Logger log = Logger.getLogger(BidBundleMinExpenses.class.getName());
  private String bidInfo;
  
  private static final int DAY_BOUND1 = 5;
  private static final int DAY_BOUND2 = 10;
  private static final int DAY_BOUND3 = 25;
  private static final int DAY_BOUND4 = 50;
  private static final double DAYS_LEFT_BOUND1 = 1.0;
  private static final double DAYS_LEFT_BOUND2 = 2.0;
  private static final double DAYS_LEFT_BOUND3 = 5.0;
  private static final double DAYS_LEFT_BOUND4 = 8.0;
  
  public BidBundleMinExpenses(SimulationStats simStats) {
    super(simStats);
    day = sim_stats.getDay();
    campaign_bid_utils = new CampaignBidUtils(simStats);
    impressions_bid_utils = new ImpressionsBidUtils(simStats);
  }
  
  public double getBid(CampaignData campaign) {
    double days_left = campaign.getDayEnd() - day;
    Random rand = new Random();
    double avgCmpRevenuePerImp = campaign.getBudget() / campaign.reachImps;
    double segment_rarity = segment_prob
    		.getSegmentProb(new ArrayList<MarketSegment>(campaign.targetSegment));
    double our_bid;
    
    double game_begining_factor = 1.0;
    double past_campaign_success_factor = 1.0;
    double random_factor = Math.max(0.8 - segment_rarity / 4.0, rand.nextDouble());
    double popularity_factor = 1.0;
    double segment_rarity_factor = 1.0 + (0.2 - segment_rarity);
    double imp_popularity_factor =
    		(0.00001 * (double) impressions_bid_utils.getImpsCompetingOnSegment(campaign.targetSegment, day)) + 1.0;
    double days_left_factor = 1.0 - (days_left - 2.0) * 0.1;
    int publisher_popularity = 0;
    
    if (day <= DAY_BOUND1) {
      game_begining_factor = 2.0 + day * 0.2;
      avgCmpRevenuePerImp *= 1.2;
    }
   
    if (campaign_bid_utils.getAvrgCampaignCompletion(day - 15, day) < 1.0) {
      past_campaign_success_factor =
    		  (2.0 - 2.0* campaign_bid_utils.getAvrgCampaignCompletion(day - 15, day)) + 1.0;
    }
    
    if (sim_stats.getPublisherStatus().getRecords(day - 1) != null) {
      publisher_popularity = ((PublisherGameStatus.PublisherStatus)
    		  sim_stats.getPublisherStatus().getRecords(day - 1)).getPopularity();
      if (publisher_popularity < 50000) {popularity_factor = 2.6;}
    }
    
    if (days_left == DAYS_LEFT_BOUND1) {
        days_left_factor = 3.0;
        if (campaign.impsTogo() > campaign.reachImps * 0.5) {random_factor = 1.0;}
        if (segment_rarity < 0.15) {segment_rarity_factor *= 1.5;}
    } else if (days_left == DAYS_LEFT_BOUND2) {
        days_left_factor = 2.5;
        if (campaign.impsTogo() > campaign.reachImps * 0.5) {random_factor = Math.max(0.9, rand.nextDouble());}
        if (segment_rarity < 0.13) {segment_rarity_factor *= 1.1;}
    } else if (days_left >= DAYS_LEFT_BOUND4) {days_left_factor = 0.1;}
    
    
    our_bid = 1000.0 * random_factor * avgCmpRevenuePerImp * 0.9 * 
      days_left_factor * segment_rarity_factor * imp_popularity_factor * 
      popularity_factor * game_begining_factor * past_campaign_success_factor;
    
    if (day >= DAY_BOUND3) {our_bid *= 1.1;}
    
    our_bid = Math.min(our_bid, getMaximalBid(campaign, day, avgCmpRevenuePerImp, days_left));
    if (campaign.getDayStart() == 1) {our_bid *= 1.2;}
    if (campaign.stats.getCost() >= campaign.getBudget() * 0.8) {our_bid *= 0.7;}
    if (campaign.getBudget() > 2.0) {our_bid *= 2.0;}
    
    bidInfo = ("Bid Bundle: "
    		+ "strategy = minimum expensses"
			+ ", reachImps = " + campaign.reachImps
			+ ", impsToGo = " + campaign.impsTogo()
			+ ", finalBid = " + our_bid);
	log.info(bidInfo);
    
    return our_bid;
  }
  
  private double getMaximalBid
  (CampaignData campaign, int day, double avgCmpRevenuePerImp, double days_left) {
	  
    double maxBidAllowed = 1000.0 * avgCmpRevenuePerImp;
    
    if (days_left <= DAYS_LEFT_BOUND3) {
    	if (campaign.impsTogo() > 0.5 * campaign.reachImps) {maxBidAllowed *= 1.5;}
    }
    if (days_left <= DAYS_LEFT_BOUND2){
      if (campaign.impsTogo() <= 0.5 * campaign.reachImps) {maxBidAllowed *= 2.0;}
      if (campaign.impsTogo() > 0.5 * campaign.reachImps) {maxBidAllowed *= 3.0;}
    }
    if (day <= DAY_BOUND2) {maxBidAllowed = 4000.0 * avgCmpRevenuePerImp;}
    return maxBidAllowed;
  }
  
  //if the campaign is about to end- make sure the factor is more significant
  public int getFactorAccordingToDaysLeftForCampaign(CampaignData campaign) {
    long campaign_length = campaign.getDayEnd() - day;
    if (campaign_length == 1) {return 3;}
    else if (campaign_length == 2) {return 2;}
    else {return 1;}
  }
  
  public int getImpressionUpperBoundPerDay(CampaignData campaign) {
    double imp_upper_bound = campaign.impsTogo();
    double quality_rate = getQualityRate(campaign);

    if (day <= DAY_BOUND1) {imp_upper_bound *= 1.5;} 
    else if (day <= DAY_BOUND3) {imp_upper_bound *= 10.0;}
    else if (quality_rate < 1.3) {imp_upper_bound *= 15.0;}
    if (campaign.stats.getCost() >= campaign.getBudget() * 0.9) {imp_upper_bound = campaign.impsTogo();}
    if (day >= DAY_BOUND4) {imp_upper_bound = campaign.impsTogo();}
    return (int)imp_upper_bound;
  }
}
