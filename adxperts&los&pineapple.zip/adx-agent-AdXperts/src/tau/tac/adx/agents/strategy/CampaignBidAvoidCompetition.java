package tau.tac.adx.agents.strategy;

import java.util.logging.Logger;

import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;
import tau.tac.adx.agents.utils.ImpressionsBidUtils;

public class CampaignBidAvoidCompetition extends AbstCampaignBidStratrgy {
	private ImpressionsBidUtils imp_bid_utils;
	//private MarketSegmentProbability ms_probability;
	private final Logger log = Logger.getLogger(CampaignBidAvoidCompetition.class.getName());
	private String bidInfo;
	
	//Constants
	private final static int NUM_OF_GAMES_BACK_TO_CHECK = 3;
	private final static double AVERAGE_IMP_FACTOR = 0.7;
	private final static double MIN_IMP_FACTOR = 1 - AVERAGE_IMP_FACTOR;
	
	private final static double GOOD_SIMILARITY_FACTOR = 0.90;
	private final static double BAD_SIMILARITY_FACTOR = 1.1;
	
	private final static double PROFIT_FACTOR = 1.01;

	public CampaignBidAvoidCompetition(SimulationStats gameData) {
		super(gameData);

		imp_bid_utils = new ImpressionsBidUtils(gameData);
		//ms_probability = new MarketSegmentProbability();
	}

	public long getCampaignBid(CampaignData pendingCampaign) {
		int day = sim_stats.getDay();
		
		double minBidOnCampaign = (pendingCampaign.reachImps / (10.0 *getQualityRate(pendingCampaign)) + 1.0);
		double avgImpCost = imp_bid_utils.getAvrgImpPrice(NUM_OF_GAMES_BACK_TO_CHECK);
		
		double estimatedImpCost;
		if(avgImpCost < 0.01)	
			estimatedImpCost = minBidOnCampaign / 1000;
		else
			estimatedImpCost = ( (avgImpCost * AVERAGE_IMP_FACTOR) + (minBidOnCampaign * MIN_IMP_FACTOR) ) / 1000 ;
		
		//Calculate Segment Similarity Factor
		double segmentSimilarityFactor = 1.0;
		int ourSameSegCamp = imp_bid_utils.getSimilarSegmentCount(pendingCampaign, day, true);
		if(ourSameSegCamp > 0){
			//lower bid to make it better
			segmentSimilarityFactor = GOOD_SIMILARITY_FACTOR;
		}
		int otherSameSegCamp = imp_bid_utils.getSimilarSegmentCount(pendingCampaign, day, false);
		if(otherSameSegCamp > 0){
			//if bidding with other agents on this segment
			//override the previous factor, and make the bid worse
			double badBidSegmentFactor = BAD_SIMILARITY_FACTOR;
			segmentSimilarityFactor = Math.pow(badBidSegmentFactor, otherSameSegCamp);
		}		

		double bid = (pendingCampaign.reachImps * estimatedImpCost) * segmentSimilarityFactor * PROFIT_FACTOR;
		
		bidInfo = ("Bid for campaign: "
				+ "strategy = avoid competition"
				+ ", reachImps = " + pendingCampaign.reachImps
				+ ", avgImpCost = " + avgImpCost
				+ ", minBidOnCampaign = " + minBidOnCampaign
				+ ", estimatedImpCost = " + estimatedImpCost
				+ ", segmentSimilarityFactor = " + segmentSimilarityFactor
				+ ", finalBid = " + (long)bid);
		log.info(bidInfo);
		
		return (long) bid;
	}

	public String getBidInfo() {
		return bidInfo;
	}

	public String bidToString() {
		return getBidInfo();
	}
}
