package tau.tac.adx.agents.strategy;

import java.util.logging.Logger;

import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;
import tau.tac.adx.agents.utils.CampaignBidUtils;

public class CampaignBidSmallProfit extends AbstCampaignBidStratrgy {
  private final Logger log = Logger.getLogger(CampaignBidSmallProfit.class.getName());
  private CampaignData last_campaign;
  private static final double PROFIT = 1.004;
  private String bidInfo;
  
  public CampaignBidSmallProfit(SimulationStats simStats) {super(simStats);}
      
  public long getCampaignBid(CampaignData campaign) {
    last_campaign = campaign;
    long bid;
    
    bid = (long)(CampaignBidUtils.getMinCampaignBid(campaign, getQualityRate(campaign)) * PROFIT);
    
    bidInfo = ("Bid for campaign: "
			+ "strategy = small profit"
			+ ", reach = " + last_campaign.reachImps
			+ ", finalBid = " + (long)bid);
	log.info(bidInfo);
    
    return bid; 
  }
  
  public String bidToString() {
    return ("reach = " + last_campaign.reachImps +
    		", currentQualityRating = " + getQualityRate(last_campaign));
  }
}
