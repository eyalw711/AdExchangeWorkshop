package tau.tac.adx.agents.strategy;

import java.util.logging.Logger;

import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;

public class BidBundleAggressive extends AbstBidBundleStrategy {
  
	BidBundleMinExpenses base_strategy;
	private final Logger log = Logger.getLogger(BidBundleAggressive.class.getName());
	private String bidInfo;
	
	private static final int DAY_BOUND1 = 4;
	private static final int DAY_BOUND2 = 5;
	private static final int DAY_BOUND3 = 15;
	private static final double DAYS_LEFT_BOUND1 = 1.0;
	private static final double DAYS_LEFT_BOUND2 = 2.0;
	private static final double DAYS_LEFT_BOUND3 = 3.0;
	private static final double DAYS_LEFT_BOUND4 = 8.0;
	private static final double BUDGET_BOUND1 = 1;
	private static final double REACH_IMPS_FACTOR1 = 0.3;
	private static final double REACH_IMPS_FACTOR2 = 0.5;
	private static final double FINISH_CAMPAIGN_FACTOR1_5 = 1.5;
	private static final double FINISH_CAMPAIGN_FACTOR2 = 2.0;
	private static final double FINISH_CAMPAIGN_FACTOR3 = 3.0;
	private static final double FINISH_CAMPAIGN_FACTOR4 = 4.0;
	
  
  public BidBundleAggressive(SimulationStats simStats) {
    super(simStats);
    base_strategy = new BidBundleMinExpenses(simStats);
  }
  
  public double getBid(CampaignData campaign) {
	int day = sim_stats.getDay();
	double days_left = campaign.getDayEnd() - day;
    double bid = ((campaign.getBudget()* 1000.0)/campaign.reachImps) ;
    double budget = campaign.getBudget();
    
    
    if (day <= DAY_BOUND2) {bid *= 1.1;}
    else if (day <= DAY_BOUND3) {bid *= 1.3;}                              
    
    if (budget > BUDGET_BOUND1) {bid *= 1.14;}
    
    if (days_left >= DAYS_LEFT_BOUND4) {bid *= 0.2;}
    else if (days_left >= DAYS_LEFT_BOUND3) {bid -= 0.08 * days_left * bid;}
    else {
      if (day <= DAYS_LEFT_BOUND2) {
    	  bid *= 3.0;
	      if (days_left == DAYS_LEFT_BOUND2) {
	    	bid *= 2.5;
	        if (campaign.impsTogo() > REACH_IMPS_FACTOR1 * campaign.reachImps) {bid *= 3.2;}
	        if (campaign.impsTogo() > REACH_IMPS_FACTOR2 * campaign.reachImps) {bid *= 3.4;}
	      }
	      if (days_left == DAYS_LEFT_BOUND1) {
	    	bid *= 3.0;
	        if (campaign.impsTogo() > REACH_IMPS_FACTOR1 * campaign.reachImps) {bid *= 3.5;}
	        if (campaign.impsTogo() > REACH_IMPS_FACTOR2 * campaign.reachImps) {bid *= 3.8;}
	      }
	      if ((campaign.impsTogo() > REACH_IMPS_FACTOR2 * campaign.reachImps) && (day == DAY_BOUND1)) {
	    	  bid *= 3.8;
	      }
      }
    }
    
    //check we don't miss the campaign's reach
    if(days_left <= 2){
    	bid = ((campaign.getBudget()* 1000.0)/campaign.reachImps);
    	if (campaign.impsTogo() > campaign.reachImps * 0.75)
    		bid *= FINISH_CAMPAIGN_FACTOR4;
    	else if (campaign.impsTogo() > campaign.reachImps * 0.55)
    		bid *= FINISH_CAMPAIGN_FACTOR3; 
    	else if (campaign.impsTogo() > campaign.reachImps * 0.35)
    		bid *= FINISH_CAMPAIGN_FACTOR2;
    	else if (campaign.impsTogo() > campaign.reachImps * 0.15)
    		bid *= FINISH_CAMPAIGN_FACTOR1_5;
    }
    
    bidInfo = ("Bid Bundle: "
    		+ "strategy = aggressive" 
			+ ", reachImps = " + campaign.reachImps
			+ ", impsToGo = " + campaign.impsTogo()
			+ ", finalBid = " + bid);
	log.info(bidInfo);
    
    return bid;
  }
  
  public int getFactorAccordingToDaysLeftForCampaign(CampaignData campaign) {
    return base_strategy.getFactorAccordingToDaysLeftForCampaign(campaign);
  }
  
  public int getImpressionUpperBoundPerDay(CampaignData campaign) {
    if (campaign.stats.getCost() > 0.5 * campaign.getBudget()) {return campaign.impsTogo();}
    return (int)(campaign.impsTogo() * 1.3);
  }
}
