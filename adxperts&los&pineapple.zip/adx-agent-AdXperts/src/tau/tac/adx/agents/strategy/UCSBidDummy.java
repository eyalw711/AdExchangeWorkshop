package tau.tac.adx.agents.strategy;

import java.util.logging.Logger;

import tau.tac.adx.agents.simulation.SimulationStats;

public class UCSBidDummy extends AbstUCSBidStrategy {
	private final Logger log = Logger.getLogger(UCSBidDummy.class.getName());
	private String bidInfo;
	
  public UCSBidDummy(SimulationStats simStats) {super(simStats);}
  
  public double getUCSBid(double ucs_target) {
	  double bid;
	  
	  bid = ucs_target * 0.2;
	  bidInfo = ("Bid for UCS: "
	    		+ "strategy = dummy"
				+ ", finalBid = " + bid);
		log.info(bidInfo);
	  
	  return bid;
	  }
}
