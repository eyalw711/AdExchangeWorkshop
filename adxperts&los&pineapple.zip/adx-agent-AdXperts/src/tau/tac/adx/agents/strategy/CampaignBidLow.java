package tau.tac.adx.agents.strategy;

import java.util.logging.Logger;

import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;
import tau.tac.adx.agents.utils.CampaignBidUtils;

public class CampaignBidLow extends AbstCampaignBidStratrgy {
  private final Logger log = Logger.getLogger(CampaignBidLow.class.getName());
  private CampaignData last_campaign;
  private String bidInfo;

  
  public CampaignBidLow(SimulationStats simStats) {super(simStats);}
  
  public long getCampaignBid(CampaignData campaign) {
    last_campaign = campaign; 
    long bid;
    
    bid = (long)(CampaignBidUtils.getMinCampaignBid(campaign, getQualityRate(campaign)));
    
    bidInfo = ("Bid for campaign: "
    		+ "strategy = low"
			+ ", reach = " + last_campaign.reachImps
			+ ", finalBid = " + (long)bid);
	log.info(bidInfo);
	
    return bid; 
  }
  
  public String bidToString() {
    return ("reach = " + last_campaign.reachImps +
    		", currentQualityRating = " + getQualityRate(last_campaign));
  }
}
