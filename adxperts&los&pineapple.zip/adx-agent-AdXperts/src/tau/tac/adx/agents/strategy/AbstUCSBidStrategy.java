package tau.tac.adx.agents.strategy;

import tau.tac.adx.agents.simulation.SimulationStats;

public abstract class AbstUCSBidStrategy {

  protected SimulationStats sim_stats;
  
  public AbstUCSBidStrategy(SimulationStats simStats) {sim_stats = simStats;}

  public abstract double getUCSBid(double paramDouble);
  
  public String getStrategyName() {return getClass().toString();}
}
