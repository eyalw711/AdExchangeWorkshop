package tau.tac.adx.agents.strategy;

import java.util.logging.Logger;

import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;

public class UCSBidLearning extends AbstUCSBidStrategy {
	
	private final Logger log = Logger.getLogger(UCSBidLearning.class.getName());
	private String bidInfo;
	
	//-------Constants-------
	private static final double PREV_BID_FOR_DAY1 = 0.1;
	
	private static final double DAY_BOUND_FOR_ERROR_LEARNING = 7;
	private static final double INITIAL_ERROR_LEARNING_RATE = 0.9;
	private static final double ERROR_LEARNING_RATE = 0.65;
	
	private static final int HELP_CAMPAIGNS_DAY_BOUND = 5;
	private static final double LOW_IMPS_BOUND = 3000.0;
	private static final double BID_HELPING_FACTOR = 1.1;	//if got campaign in trouble, add 10% to the bid
	//-----------------------

	public UCSBidLearning(SimulationStats simStats) { super(simStats); }

	public double getUCSBid(double target_level) {
		double prev_ucs_level = sim_stats.getUcsLevel();
		double prev_bid = sim_stats.getPrevUcsBid();
		int currDay = sim_stats.getDay();
		
		if (prev_bid == 0.0) {
			prev_bid = PREV_BID_FOR_DAY1;
		}
		
		//set error_learning_rate
		double error_learning_rate;
		if(currDay < DAY_BOUND_FOR_ERROR_LEARNING)
			error_learning_rate = INITIAL_ERROR_LEARNING_RATE;
		else
			error_learning_rate = ERROR_LEARNING_RATE;
		
		//set bid
		double our_bid = prev_bid*(1.0 + ( ( target_level - prev_ucs_level ) * error_learning_rate ));		
		
		//if we're not in the first days
		if (currDay > HELP_CAMPAIGNS_DAY_BOUND) {
			// check if there is a campaign that needs more UCS
			for (CampaignData campaign : sim_stats.getOurCampaignsData()) {
				if (campaign.getDayEnd() == currDay + 1) {
					double imps_left = campaign.reachImps - campaign.stats.getTargetedImps();
					if (imps_left > LOW_IMPS_BOUND) {
						//if we got campaigns in trouble, give BID_HELPING_FACTOR precent more for bid
						return (our_bid * BID_HELPING_FACTOR);	
					}
				}
			}
		}
		
		bidInfo = ("Bid for UCS: "
	    		+ "strategy = learning"
				+ ", UCS level = " + sim_stats.getUcsLevel()
				+ ", finalBid = " + our_bid);
		log.info(bidInfo);
		
		return our_bid;
	}
}
