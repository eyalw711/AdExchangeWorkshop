package tau.tac.adx.agents.strategy;

import java.util.logging.Logger;

import tau.tac.adx.agents.simulation.SimulationStats;
import tau.tac.adx.agents.utils.ImpressionsBidUtils;

public class UCSTarget {
	
  private final Logger log = Logger.getLogger(UCSTarget.class.getName());
  private SimulationStats sim_stats;
  private ImpressionsBidUtils imp_bid_utils;
  private String bidInfo;

  
  private static final int IMPS_TO_GO_LOWER_BOUND = 0;
  private static final int IMPS_TO_GO_MED_BOUND = 500;
  private static final int IMPS_TO_GO_UPPER_BOUND = 1500;
  
  private static final double TARGET_LEVEL_LOW = 0.0;
  private static final double TARGET_LEVEL_MED_LOW = 0.67;
  private static final double TARGET_LEVEL_MED_HIGH = 0.75;
  private static final double TARGET_LEVEL_HIGH = 0.83;
  private static final double TARGET_LEVEL_SUPER = 0.98;
  
  private static final int EARLY_DAYS_BOUND = 6;
  
  public UCSTarget(SimulationStats _sim_stats) {
	sim_stats = _sim_stats;
	imp_bid_utils = new ImpressionsBidUtils(_sim_stats);
  }
  
  
  public double getUCSTarget() {
    int imps_to_go = imp_bid_utils.getTotalImpsCompetingFor(sim_stats.getDay() + 1);
    double target_level;
    
    if (sim_stats.getDay() <= EARLY_DAYS_BOUND) {target_level = TARGET_LEVEL_SUPER;}
    
    if (imps_to_go == IMPS_TO_GO_LOWER_BOUND) {target_level = TARGET_LEVEL_LOW;}
    else {
      if (imps_to_go <= IMPS_TO_GO_MED_BOUND) {target_level = TARGET_LEVEL_MED_LOW;}
      else {
        if (imps_to_go <= IMPS_TO_GO_UPPER_BOUND) {target_level = TARGET_LEVEL_MED_HIGH;}
        else {return TARGET_LEVEL_HIGH;}	//imps_to_go > IMPS_TO_GO_UPPER_BOUND
      }
    }
    bidInfo = ("Bid for UCS: "
    		+ "strategy = target"
			+ ", UCS level = " + sim_stats.getUcsLevel()
			+ ", imps to go = " + imps_to_go
			+ ", finalBid = " + target_level);
	log.info(bidInfo);
    
    return target_level;
  }
}
