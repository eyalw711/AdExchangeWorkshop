package tau.tac.adx.agents.strategy;

import tau.tac.adx.agents.gameStatus.QualityRateGameStatus;
import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;

public abstract class AbstCampaignBidStratrgy
{
  protected SimulationStats sim_stats;;
  
  public AbstCampaignBidStratrgy(SimulationStats simStats) {sim_stats = simStats;}
  
  public abstract long getCampaignBid(CampaignData paramCampaignData);
  
  public abstract String bidToString();
  
  protected double getQualityRate(CampaignData campaign) {
	  if (sim_stats.getQualityRatingDataHistory().getRecords(sim_stats.getDay() - 1) != null) {
		  return((QualityRateGameStatus.QualityRateStatus)sim_stats
				  .getQualityRatingDataHistory().getRecords(sim_stats.getDay() - 1)).getQualityRate();
		  }
	  return 1.0;
}
  
  public String getStrategyName() {return getClass().toString();}
}
