package tau.tac.adx.agents.utils;

import java.util.Set;

import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;
import tau.tac.adx.report.adn.MarketSegment;

public abstract class BidUtils {
	
	protected SimulationStats currSimStats;
	
	protected BidUtils(SimulationStats _simStats) {
		currSimStats = _simStats;
	}
	
	/*Given two market segments, is one of them fully contained in the other*/
	protected boolean doSegmentsCollide(Set<MarketSegment> segmentsBlock_1, Set<MarketSegment> segmentsBlock_2) {
		int matches_1 = 0;
		int matches_2 = 0;
		if (segmentsBlock_1.size() < segmentsBlock_2.size()) {
			for (MarketSegment seg : segmentsBlock_1) {
				if (segmentsBlock_2.contains(seg)) {
					matches_1++;
				}
			}
		} else {
			for (MarketSegment seg : segmentsBlock_2) {
				if (segmentsBlock_1.contains(seg)) {
					matches_2++;
				}
			}
		}
		return (matches_1 == segmentsBlock_1.size()) || (matches_2 == segmentsBlock_2.size());
	}
	
	public static boolean isCampaignActive(int currDay, CampaignData campaign){
		return ((campaign.getDayStart() <= currDay) && (campaign.getDayEnd() >= currDay));
	}
}
