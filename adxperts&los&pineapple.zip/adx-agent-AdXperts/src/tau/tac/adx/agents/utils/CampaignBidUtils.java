package tau.tac.adx.agents.utils;

import java.util.Collection;

import tau.tac.adx.agents.gameStatus.CampaignGameStatus;
import tau.tac.adx.agents.gameStatus.CurrentStatus;
import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;

public class CampaignBidUtils extends BidUtils{
	
	public CampaignBidUtils(SimulationStats _simStats){
		super(_simStats);
	}
	
	/*Count how many campaigns are currently in progress*/
	public int numOfActiveCampaigns(int end) {
		Collection<CurrentStatus> campaigns = currSimStats.getCampaignStatus().getRecordsValues();
		int active = 0;
		for (CurrentStatus dailyReport : campaigns) {
			CampaignGameStatus.CampaignStatus currCampaignReport =
					(CampaignGameStatus.CampaignStatus) dailyReport;
			//if campaign is still active
			if(isCampaignActive(end, currCampaignReport.getCampignData())){
				active++;
			}
		}
		return active;
	}
	
	/*Get the average of our campaigns completion percentage*/
	public double getAvrgCampaignCompletion(int start, int end) {
		double avrage = 0.0;
		int count = 0;
		for (CampaignData currCampaign : currSimStats.getOurCampaignsData()) {
			if(isCampaignActive(end, currCampaign)){
				avrage += (double)((double)currCampaign.stats.getTargetedImps()
						/ (double)currCampaign.reachImps);
				count++;
			}
		}
		if (count > 0) {
			return avrage / count;
		}
		return 1.0;
	}

	public int numOfCompletedCampaigns(int past_games_num) {
		int count = 0;
		int game_num = currSimStats.getGameNumber();
		
		while ((game_num > (game_num - past_games_num)) && (game_num >= 0)) {
			for (int i = 0; i < currSimStats.getCampaignStatus().getRecordsNum(game_num); i++) {
				if (currSimStats.getCampaignStatus().getRecords(i, game_num) != null) {
					CampaignGameStatus.CampaignStatus currCampaignReport
					= (CampaignGameStatus.CampaignStatus) currSimStats.getCampaignStatus()
							.getRecords(i, game_num);
					if (currCampaignReport.getWon()) {
						if (game_num == currSimStats.getGameNumber()) {
							if (currCampaignReport.getCampignData().getDayEnd() < currSimStats.getDay()) 
								count++;
						}
						else
							count++;
					}
				}
			}
			game_num--;
		}
		return count;
	}

	
	/*get the number of days we're loosing campaigns in a row*/
	public int getLoseStreaks(int end) {
		if(end == 0)
			return 0;
		
		int lastDayWon = end - 1;
		int campBidsLost = 0;
		CampaignGameStatus.CampaignStatus currCampaign =
				(CampaignGameStatus.CampaignStatus) currSimStats
				.getCampaignStatus().getRecords(lastDayWon);
		while ((currCampaign != null) && (lastDayWon >= 0) && (!currCampaign.getWon())) {
			campBidsLost++;
			lastDayWon--;
			currCampaign = (CampaignGameStatus.CampaignStatus) currSimStats
					.getCampaignStatus().getRecords(lastDayWon);
		}
		return campBidsLost;
	}
	
	
	
	public static double getMinCampaignBid(CampaignData campaign, double quality){
		double bid = Math.ceil(campaign.reachImps / (10.0 * quality));
		
		return bid;
	}
}
