package tau.tac.adx.agents.utils;

import java.util.Set;

import tau.tac.adx.agents.gameStatus.CampaignGameStatus;
import tau.tac.adx.agents.simulation.CampaignData;
import tau.tac.adx.agents.simulation.SimulationStats;
import tau.tac.adx.demand.CampaignStats;
import tau.tac.adx.report.adn.MarketSegment;

public class ImpressionsBidUtils extends BidUtils{
	
	public ImpressionsBidUtils(SimulationStats _simStats){
		super(_simStats);
	}
	
	/*Get total number of impressions we're bidding on*/
	public int getTotalImpsCompetingFor(int end) {
		int impressions = 0;
		for (CampaignData currCampaign : currSimStats.getOurCampaignsData()) {
			if(isCampaignActive(end, currCampaign)){
			//if ((currCampaign.getDayStart() <= tillDay) && (currCampaign.getDayEnd() > tillDay)) {
				impressions += currCampaign.impsTogo();
			}
		}
		return impressions;
	}
	
	/*Get number of impressions in a market segment currently that are targeted by campaigns*/
	public long getImpsCompetingOnSegment(Set<MarketSegment> segment, int day) {
		long impCount = 0;
		for (int i = 1; i < day; i++) {
			CampaignGameStatus.CampaignStatus currCampaignReport =
					(CampaignGameStatus.CampaignStatus) currSimStats
					.getCampaignStatus().getRecords(i);
			if (currCampaignReport != null) {
				if((!currCampaignReport.getWon()) && isCampaignActive(day, currCampaignReport.getCampignData())){
					if (doSegmentsCollide(segment, currCampaignReport.getCampignData().targetSegment)) {
						impCount += currCampaignReport.getCampignData().reachImps;
					}
				}
			}
		}
		return impCount;
	}
	
	/*Given a campaign, count how many of our campaigns collide with it*/
	public int getSimilarSegmentCount(CampaignData campData, int day, boolean sameAsmine) {
		int ourCampCount = 0;
		int otherCampCount = 0;
		Set<MarketSegment> ourSegments = campData.targetSegment;
		
		for (int i = 1; i < day; i++) {
			CampaignGameStatus.CampaignStatus currCampaignReport =
					(CampaignGameStatus.CampaignStatus) currSimStats
					.getCampaignStatus().getRecords(i);
			if (currCampaignReport != null) {
				CampaignData currCampaign = currCampaignReport.getCampignData();
				//only consider running campaigns
				if(isCampaignActive(day, currCampaign)){
					Set<MarketSegment> targetSet = currCampaign.targetSegment;
					
					if (doSegmentsCollide(targetSet, ourSegments)) {
						if (currCampaignReport.getWon()) {
							ourCampCount++;
						} 
						else {
							otherCampCount++;
						}
					}
				}
			}
		}
		if (sameAsmine) {
			return ourCampCount;
		}
		return otherCampCount;
	}
	
	/*Get average payment per impression we've won*/
	public double getAvrgImpPrice(int prevDayLimit) {
		int count = 0;
		double sum = 0.0;

		int currentGameNumber = currSimStats.getGameNumber();
		int numRecords = currSimStats.getCampaignStatus().getRecordsNum(currentGameNumber);
		
		for (int i = numRecords; i > numRecords - prevDayLimit; i--) {
			if (currSimStats.getCampaignStatus().getRecords(i, currentGameNumber) != null) {
				CampaignGameStatus.CampaignStatus currCampaign = (CampaignGameStatus.CampaignStatus) currSimStats
						.getCampaignStatus().getRecords(i, currentGameNumber);
				if (currCampaign.getWon()) {
					CampaignData currCampData = currCampaign.getCampignData();
					CampaignStats campStats = currCampData.stats;
					if (campStats.getTargetedImps() + campStats.getOtherImps() != 0.0) {
						double cost = campStats.getCost();
						double targetedImps = campStats.getTargetedImps();
						double otherImps = campStats.getOtherImps();

						// only campaigns that already ended are taken into
						// account
						if (currentGameNumber == currSimStats.getGameNumber()) {
							if (currCampData.getDayEnd() < currSimStats.getDay()) {
								sum += cost / (targetedImps + otherImps);
								count++;
							}
						} else {
							sum += cost / (targetedImps + otherImps);
							count++;
						}
					}
				}
			}
		}
		if (count == 0) {
			return 0.0;
		}
		return sum / count;
	}
}
