package tau.tac.adx.agents.utils;

import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.File;
import tau.tac.adx.report.adn.MarketSegment;
import java.io.IOException;
import java.util.ArrayList;
import java.io.BufferedReader;

public class MarketSegmentProbability {
	// total population count
	private int sumPopulation;
	// for each market segment keep it's population size
	private ArrayList<MarketSegmentBlock> segSizes = new ArrayList<MarketSegmentBlock>();

	public MarketSegmentProbability() {sumPopulation = calcSumPopulation();}

	/*
	 * Given a set of market segments, return the probability of a single
	 * impression being in that market segment
	 */
	public double getSegmentProb(ArrayList<MarketSegment> marketSegments) {
		double sum = 0.0;
		for (MarketSegmentBlock currProb : segSizes) {
			int popCount = 0;
			for (MarketSegment curSeg : marketSegments) {
				if (currProb.hasSegment(curSeg)) {popCount++;}
			}
			if (marketSegments.size() == popCount) {sum += currProb.getSegmentSize();}
		}
		return (sum / sumPopulation);
	}

	private int calcSumPopulation() {
		BufferedReader br = null;
		//String input;

		int sumPop = 0;

		try {
			String path = "config" + File.separator + "segments_sizes.csv";
			br = new BufferedReader(new FileReader(path));
			try{
			String input = br.readLine(); // ignore titles line
			while ((input = br.readLine()) != null) {
				String[] seg = input.split(",");
				ArrayList<MarketSegment> segments = new ArrayList<MarketSegment>();
				for (int i = 0; i < 3; i++) {
					String temp = seg[i];
					if (temp.equals("young")) {segments.add(MarketSegment.YOUNG);}
					else if (temp.equals("old")) {segments.add(MarketSegment.OLD);}					
					else if (temp.equals("low")) {segments.add(MarketSegment.LOW_INCOME);}
					else if (temp.equals("high")) {segments.add(MarketSegment.HIGH_INCOME);}
					else if (temp.equals("female")) {segments.add(MarketSegment.FEMALE);}
					else if (temp.equals("male")) {segments.add(MarketSegment.MALE);}
					else {
						// invalid string
					}
				}
				int size = Integer.parseInt(seg[3]);
				MarketSegmentBlock currSegmentProb = new MarketSegmentBlock(segments, size);
				segSizes.add(currSegmentProb);
				sumPop += size;
			}
			}finally {br.close();}
		} catch (FileNotFoundException e) {e.printStackTrace();}
		catch (NumberFormatException | IOException e) {e.printStackTrace();}
		
		return sumPop;
	}

}
