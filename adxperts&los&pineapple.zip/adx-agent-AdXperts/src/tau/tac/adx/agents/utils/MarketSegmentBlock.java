package tau.tac.adx.agents.utils;

import tau.tac.adx.report.adn.MarketSegment;
import java.util.ArrayList;

/*Class for managing Market Segment blocks*/
public class MarketSegmentBlock {
	private ArrayList<MarketSegment> marketSegments;
	private int size = 0;

	public MarketSegmentBlock(ArrayList<MarketSegment> _segments, int _size) {
		marketSegments = new ArrayList<MarketSegment>(_segments);
		size = _size;
	}
	
	//add segment, and set new probability
	public void addSegment(MarketSegment _segment, int _new_size){
		marketSegments.add(_segment);
		size = _new_size;
	}

	//check if some market segments are fully contained in our market segments list
	public boolean containsSegment(ArrayList<MarketSegment> seg) {return (marketSegments.contains(seg));}

	//check if a segment is included in our list
	public boolean hasSegment(MarketSegment seg) {return marketSegments.contains(seg);}

	//population size (out of 10,000) that agree with the market segment
	public int getSegmentSize() {return size;}
}
