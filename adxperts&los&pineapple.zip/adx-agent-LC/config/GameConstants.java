package config;

public class GameConstants {
	public static final Double pUserContinuation = 0.3;
	public static final Double pRandomCampaignAllocation = 0.36;
	public static final Integer maxUserDailyImpressions = 6;
	public static final Double initialReservePrice = 0.005;
	public static final Double reservePriceVariance = 0.02;
	public static final Double reservePriceLearningRate = 0.2;
	public static final Integer shortCampaignDuration = 3;
	public static final Integer mediumCampaignDuration = 5;
	public static final Integer longCampaignDuration = 10;
	public static final Double lowCampaignReachFactor = 0.2;
	public static final Double mediumCampaignReachFactor = 0.5;
	public static final Double highCampaignReachFactor = 0.8;
	public static final Double maxCampaignCostByImpression = 0.001;
	public static final Double minCampaignCostByImpression = 0.0001;
	public static final Double qualityRatingLearningRate = 0.6;
	public static final Integer gameLength = 60;
	public static final Integer realTimeSecondsPerDay = 10;
	public static final Double pUcsUserRevelation = 0.9;
	public static final Double initialDayClassificationAcc = 0.9;
	public static final Double m_lowerRatingLimit = 0.8;
	public static final Double upperPILimit = 0.9; //MUST CHANGE!!!! 
	public static final Double initalUCSBid = 0.2;//MUST CHANGE!!!!
	public static final Double firstCiValue = 1.0;
	public static final Double Ggreed = 1.2; /* Ggreed>1 is a factor describing how greedy Los Capaors is when bidding for a contract. It is used to update the CI (competeing index). LC is more generous if Ggreed is set high.*/
	public static final Double GUCS = 0.2; /* 0.5<GUCS<1 means the percentage the bid in UCS auctions should be scaled up by in order to receive ahigher UCS level */
	public static final Double GUCSPanic = 0.2;
	public static final Double minImp = 0.75;
	
	//BidBundle
	public static final Double fixedBudgetPrecentege = 0.85;
	public static final Double panicDays = 0.33;
	public static final Double smallReach = 0.4;
	public static final Double tooLittleBudget = 0.2;
	public static final Integer panicRatio = 5;
	public static final Double budgetLimit = 1.3;
	
	/*greek constants
	public static final Double campaignGoal = 1.2;
	public static final Double rbidGuideFactor = 8.0;
	public static final Integer AdXGuideFactor = 4;
	public static final Double AdXRatio = 0.7;
	public static final Double CampaignCut = 0.1;
	public static final Double UCSRatio = 0.2;
	*/

}