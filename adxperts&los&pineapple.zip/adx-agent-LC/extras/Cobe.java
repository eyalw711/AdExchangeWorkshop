package extras;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import config.GameConstants;

import tau.tac.adx.report.adn.MarketSegment;
import extras.CampaignData;



public class Cobe {
	
	//Constants
	final static double RCampaignMin = GameConstants.minCampaignCostByImpression;
	final static double RCampaignMax = GameConstants.maxCampaignCostByImpression;
	final static double g_Cgreed = GameConstants.Ggreed;
	//final double m_uppercampOpperBidLimit = GameConstants.uppercampOpperBidLimit;
	final static double m_lowerRatingLimit = GameConstants.m_lowerRatingLimit;
	final static double m_upperPILimit = GameConstants.upperPILimit;
	
	//Variable
	static int m_day;
	
	//List Members of our and market campaign data
	//static List<CampaignData> m_OurActiveCampaignData;
	static List<CampaignData> m_TotalMarketActiveCampaignData;
	
	//campaign Data members
	static CampaignData m_campaignData;
	static int m_lengthOfCampaign;
	static Set<MarketSegment> m_Segements;
	static Set<Set<MarketSegment>> m_powerSegments;
	static int m_CampaignSegmentSize;
	
	//member that are our agent data - our rating and our competing index 
	static double m_CI = GameConstants.firstCiValue; 	//our competing index  - NEED TO INSERT INITIAL CI VALUE;
	static double m_myRating;
	
	//Last campaign opportunity suggestion
	static CampaignData m_lastSuggestionResultsResults;
		
	//MABYE SHOULD DELETE	
	List<ArrayList<HashMap<MarketSegment, Integer>>> m_ourOverlapDaysList = new ArrayList<ArrayList<HashMap<MarketSegment, Integer>>>();	 
	List<ArrayList<HashMap<MarketSegment, Integer>>> m_marketOverlapDaysList = new ArrayList<ArrayList<HashMap<MarketSegment, Integer>>>();	 
	//-----------------------------------
	
	
	
	/*the main function of the engine:
	 * first it initial all the members of the class
	 * second, it make a calculation for the offer 
	 */
	public static long CalcPayment(CampaignData campaign,Map<Integer,CampaignData> ourActiveCampaign,
		Map<Integer,CampaignData> MarketActiveCampaign,int day,CampaignData lastCampaign
		,double rating){
		double gradeOfSegmetns=0.0;
		if ((MarketActiveCampaign==null)||(MarketActiveCampaign.size()==0)){
			gradeOfSegmetns=campaign.getreachImps()/((campaign.getdayEnd()-campaign.getdayStart()+1)*MarketSegment.marketSegmentSize(campaign.gettargetSegment()));
		}
		else{
			InitialMembers(campaign,ourActiveCampaign,MarketActiveCampaign,day,lastCampaign,rating);
			gradeOfSegmetns = CalcGardeOfSegmentsType();
		}
		System.out.println("Before suggestion reach imps is: "+campaign.getreachImps());
		return (long)(Math.ceil(gradeOfSegmetns*campaign.getreachImps()));
		
	}
	
	
	
	/*the main calculation Function :
	 * calc the CI - how competing we are
	 * calc the PI
	 * verify that the offer is in the limitation of the spec
	 * */
	private static double CalcGardeOfSegmentsType() {
		
		double PI;
		//int Cs = m_CampaignSegmentSize;
		//int CL = m_lengthOfCampaign;
		//int Crl = (int) m_campaignData.getreachImps();
		//int Cr = Cs*CL*Crl;
		//int Cr = (int) m_campaignData.getreachImps();
		//double minbid = Cr*RCampaignMin/m_myRating;
		//double maxbid = Cr*RCampaignMax*m_myRating;
		double maxbid = 1;
		double minbid = 0.1;
		calcHowCumpeting(m_lastSuggestionResultsResults);
		PI = calcHowPopular();
		System.out.println("LosCaparos PI is: "+PI+" ,bidding regular");
		///VERFIY WE ARE IN THE RIGHT LIMITATION!!!!
		if(m_myRating < m_lowerRatingLimit){
			System.out.println("LosCaparos Rating is low, bidding minimum");
			return minbid;
		}
		else if(PI > m_upperPILimit){
			System.out.println("LosCaparos PI is high, bidding maximum");
			return maxbid;
		}
		System.out.println("LosCaparos PI is good bidding PI*CI: "+m_CI*PI+" ,bidding regular");
		return Math.max(minbid,Math.min(m_CI*PI,maxbid));
				
	}
	
	
	//Calc the CI   - still need to check how to get last suggestion result
	private static void calcHowCumpeting(CampaignData lastcampaginDay) {
		if (m_day!=0){
			if (lastcampaginDay.IsWin() == true){
				// we win - increase m_CI if it's not random campaign
				if(lastcampaginDay.getBudget()!=(lastcampaginDay.getMyBid()/1000)){
					m_CI = m_CI*g_Cgreed;
					System.out.println("LosCaparos won last campaign CI is enlarged: "+m_CI);
				}
			}		
			else{
				// we didn't win - reduce m_CI
				m_CI  = m_CI/g_Cgreed;
				System.out.println("LosCaparos lose last campaign CI is reduced: "+m_CI);
			}
		}
	}

	//Calc the PI
	private static double calcHowPopular() {
		double sum=0;

		//int WS = CalcWeightOfPowerSetSegmentPop();
		sum = Pop();
		sum = sum/(m_CampaignSegmentSize*m_lengthOfCampaign);

		return sum;
	}

	//function pop(s,t)
	private static double Pop() {
		double innerSum = 0;
		int timeOfOverlap;
		int Wi;
		int activeCampaignLength;
		List<CampaignData> allCampaignsList = new ArrayList<CampaignData>(m_TotalMarketActiveCampaignData);
		//allCampaignsList.addAll(m_OurActiveCampaignData);
		//allCampaignsList.add(m_campaignData);


		//run on all active campaigns - except the pending campaign
		for (Set<MarketSegment> segemnts : m_powerSegments) {
			for (CampaignData activeCamp : allCampaignsList) {
				timeOfOverlap = (int) (Math.min(m_campaignData.getdayEnd(),activeCamp.getdayEnd())-m_campaignData.getdayStart()+1);
				Set<MarketSegment> marketSegment = activeCamp.gettargetSegment();
				if (marketSegment == segemnts) {

					activeCampaignLength = (int) (activeCamp.getdayEnd() - activeCamp.getdayStart() + 1);
					innerSum += ((activeCamp.getreachImps()*timeOfOverlap)/(activeCampaignLength));
				}
				Wi = MarketSegment.marketSegmentSize(marketSegment);
				innerSum = innerSum*Math.min(1,(m_CampaignSegmentSize/Wi));
			}
		}

		return innerSum+m_CampaignSegmentSize;
	}
	

	// initial all the members for future calculation
	private static void InitialMembers(CampaignData campaign, Map<Integer, CampaignData> ourActiveCampaign,
			Map<Integer, CampaignData> marketActiveCampaign, int day, CampaignData lastCampaign,
			double rating) {
		//initial new campaign details
		m_campaignData = campaign;
		m_lengthOfCampaign = (int) (m_campaignData.getdayEnd()- m_campaignData.getdayStart()+1);
		m_Segements = campaign.gettargetSegment();
		m_powerSegments = GetPowerSetOfMarketSegments(m_Segements);
		m_CampaignSegmentSize = MarketSegment.marketSegmentSize(m_Segements);
		//initial List of Active Campaigns
		//m_OurActiveCampaignData = ConvertToList(ourActiveCampaign);
		m_TotalMarketActiveCampaignData = ConvertToList(marketActiveCampaign);
		//initial last campaign opportunity result
		m_lastSuggestionResultsResults = lastCampaign;
		//initial our agent 
		//m_myRating = m_campaignData.getMyRating();
		m_myRating = rating;
		//initial helpfull parms
		m_day = day;
		// maybe should delete ---------------------------//
		//m_ourOverlapDaysList = InitOverlapDaysList();
		//m_marketOverlapDaysList = InitOverlapDaysList();
		//m_ourOverlapDaysList = GetOverlapBetweenActiveTargetedSegements(m_OurActiveCampaignData,m_ourOverlapDaysList);
		//m_marketOverlapDaysList = GetOverlapBetweenActiveTargetedSegements(m_TotalMarketActiveCampaignData,m_marketOverlapDaysList);
		// maybe should delete ---------------------------//
	}
	


	private static List<CampaignData> ConvertToList(Map<Integer,CampaignData> CampDict){
		List<CampaignData> campaignDataList = new ArrayList<CampaignData>();
		for (Map.Entry<Integer, CampaignData> campaign : CampDict.entrySet())
		{
			campaignDataList.add(campaign.getValue());
		}
		return campaignDataList;
		
	}
	
	
	//this function returns the powerSet Of any set of segments
		public static Set<Set<MarketSegment>> GetPowerSetOfMarketSegments(Set<MarketSegment> pendingMarketSegments) {
			Set<Set<MarketSegment>> powerSet = new HashSet<Set<MarketSegment>>();
			
			List<Set<MarketSegment>> cmarketSegments = new ArrayList<Set<MarketSegment>>();
			cmarketSegments.add(MarketSegment.compundMarketSegment1(MarketSegment.FEMALE));
			cmarketSegments.add(MarketSegment.compundMarketSegment1(MarketSegment.MALE));
			cmarketSegments.add(MarketSegment.compundMarketSegment1(MarketSegment.YOUNG));
			cmarketSegments.add(MarketSegment.compundMarketSegment1(MarketSegment.OLD));
			cmarketSegments.add(MarketSegment.compundMarketSegment1(MarketSegment.LOW_INCOME));
			cmarketSegments.add(MarketSegment.compundMarketSegment1(MarketSegment.HIGH_INCOME));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.FEMALE,MarketSegment.YOUNG));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.FEMALE,MarketSegment.OLD));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.MALE,MarketSegment.YOUNG));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.MALE,MarketSegment.OLD));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.FEMALE,MarketSegment.LOW_INCOME));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.FEMALE,MarketSegment.HIGH_INCOME));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.MALE,MarketSegment.LOW_INCOME));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.MALE,MarketSegment.HIGH_INCOME));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.YOUNG,MarketSegment.LOW_INCOME));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.YOUNG,MarketSegment.HIGH_INCOME));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.OLD,MarketSegment.LOW_INCOME));
			cmarketSegments.add(MarketSegment.compundMarketSegment2(MarketSegment.OLD,MarketSegment.HIGH_INCOME));
			cmarketSegments.add(MarketSegment.compundMarketSegment3(MarketSegment.FEMALE,MarketSegment.LOW_INCOME,MarketSegment.YOUNG));
			cmarketSegments.add(MarketSegment.compundMarketSegment3(MarketSegment.FEMALE,MarketSegment.LOW_INCOME,MarketSegment.OLD));
			cmarketSegments.add(MarketSegment.compundMarketSegment3(MarketSegment.MALE,MarketSegment.LOW_INCOME, MarketSegment.YOUNG));
			cmarketSegments.add(MarketSegment.compundMarketSegment3(MarketSegment.MALE,MarketSegment.LOW_INCOME, MarketSegment.OLD));
			cmarketSegments.add(MarketSegment.compundMarketSegment3(MarketSegment.FEMALE,MarketSegment.HIGH_INCOME,MarketSegment.YOUNG));
			cmarketSegments.add(MarketSegment.compundMarketSegment3(MarketSegment.FEMALE,MarketSegment.HIGH_INCOME,MarketSegment.OLD));
			cmarketSegments.add(MarketSegment.compundMarketSegment3(MarketSegment.MALE,MarketSegment.HIGH_INCOME, MarketSegment.YOUNG));
			cmarketSegments.add(MarketSegment.compundMarketSegment3(MarketSegment.MALE,MarketSegment.HIGH_INCOME, MarketSegment.OLD));
			
			for (Set<MarketSegment> marketSegment : cmarketSegments){
				//pending segments size is smaller
				if (marketSegment.size() > pendingMarketSegments.size()){
					if (DoesContain(marketSegment,pendingMarketSegments)){
						powerSet.add(marketSegment);
					}
				}
				//pending segments size is bigger
				else{
					if (DoesContain(pendingMarketSegments,marketSegment)){
						powerSet.add(marketSegment);
					}
				}
			}
			return powerSet;
		}

		/*this function run over the two sets of segment and check that smaller is 
		FULLY contained in the bigger one.
		if not return false*/
		private static boolean DoesContain(Set<MarketSegment> biggerMarketSegments,Set<MarketSegment> smallermarketSegment) {
			MarketSegment[] biggerMarketSegmentArr = biggerMarketSegments.toArray(new MarketSegment[biggerMarketSegments.size()]);
			MarketSegment[] smallerMarketSegmentArr = smallermarketSegment.toArray(new MarketSegment[smallermarketSegment.size()]);
			int sum;
			for (MarketSegment smallmarketSegment: smallerMarketSegmentArr){
				sum=0;
				for (MarketSegment bigmarketSegment: biggerMarketSegmentArr){
					if (bigmarketSegment == smallmarketSegment){
						sum++;
					}
				}
				if(sum == 0){
					return false;
				}
			}
			return true;
		}

	
	
	
	
	//--------------------------------------------------------------------
	//--------------------------------------------------------------------
	//--------------------------------------------------------------------
	//             		MAYBE SHOULD BE DELETED
	//--------------------------------------------------------------------
	//--------------------------------------------------------------------
	//--------------------------------------------------------------------

	
	
	/*initial the overlap list (list of day, which each day
	has a list which every cell has of the power DICTIONARY of segment
	the key is the segemnt and the value is the number of over lap in this day 
	of this specific segment*/
	/*private List<ArrayList<HashMap<MarketSegment, Integer>>> InitOverlapDaysList() {
		List<ArrayList<HashMap<MarketSegment, Integer>>> ourOverlapDaysList= new ArrayList<ArrayList<HashMap<MarketSegment, Integer>>>(m_lengthOfCampaign);
		ArrayList<HashMap<MarketSegment, Integer>> SegmentApearanceDict = InitPowerSegemntWithNumOfOverlap(m_powerSegments);
		for (int i=0; i<ourOverlapDaysList.size();i++){
			
			ourOverlapDaysList.add(SegmentApearanceDict);
		}
		return ourOverlapDaysList;
		
	}

	//init the inner list (the list contain the powerset of all market segments)
	private ArrayList<HashMap<MarketSegment, Integer>> InitPowerSegemntWithNumOfOverlap(
			List<Set<MarketSegment>> m_powerSegments) {
		
		ArrayList<HashMap<MarketSegment, Integer>> SegmentApearanceDict = new ArrayList<HashMap<MarketSegment, Integer>>();
		HashMap<MarketSegment,Integer> newmarketSegemntHashSet = new HashMap<MarketSegment,Integer>();
		for (Set<MarketSegment> marketSegemntSet : m_powerSegments){  
			for (MarketSegment marketSegemnt : marketSegemntSet){
				newmarketSegemntHashSet.put(marketSegemnt, 0);
			}
			SegmentApearanceDict.add(newmarketSegemntHashSet);// check that every day get the same
		}
		return SegmentApearanceDict;
	}
	
	private List<ArrayList<HashMap<MarketSegment, Integer>>> GetOverlapBetweenActiveTargetedSegements(List<CampaignData> campaignDataList,
			List<ArrayList<HashMap<MarketSegment, Integer>>> OverlapDaysList) {
		
		List<Integer> campaignLength = new ArrayList<Integer>(m_lengthOfCampaign);
		for (CampaignData activeCampaign : campaignDataList){
			
			Set<MarketSegment> activeSegemnts = activeCampaign.gettargetSegment();
			
			if (m_powerSegments.contains(activeSegemnts)){
				//update the specific overlapDict (our or total market)
				OverlapDaysList=UpdateOverlapSegmentDict(activeCampaign,OverlapDaysList);
			}
		}
		return OverlapDaysList;
		
	}
	
	//update the list of overlap segment (update the member m_ourOverlapDaysList\m_marketOverlapDaysList) 
	private List<ArrayList<HashMap<MarketSegment, Integer>>> UpdateOverlapSegmentDict(CampaignData activeCampaign,
			List<ArrayList<HashMap<MarketSegment, Integer>>> OverlapDaysList) {
		
		
		int DayEndOfOverlap = (int) (m_campaignData.getdayEnd() > activeCampaign.getdayEnd() ? activeCampaign.getdayEnd(): m_campaignData.getdayEnd());
		int lengthOfOverlap = (int) (DayEndOfOverlap- m_campaignData.getdayStart()+1);  
		//runs over the days
		for (int i=0;i<lengthOfOverlap;i++){			
			
			ArrayList<HashMap<MarketSegment, Integer>> marketSegemntAndOverlap = OverlapDaysList.get(i);		//get the dict of all segment of the specific day
			//run over the segments sets list per day
			for (int j=0; j<marketSegemntAndOverlap.size();j++ ){
				HashMap<MarketSegment, Integer> segmentSetOverlap = marketSegemntAndOverlap.get(j);
				Set<MarketSegment> activeCampignSegment = activeCampaign.gettargetSegment();
				boolean doesContain = DoesContained(activeCampignSegment,segmentSetOverlap.keySet());
				if (doesContain){
					// run on each market segment in the set
					for (MarketSegment marketsegment : activeCampignSegment){
						int numOfOverlap = segmentSetOverlap.get(marketsegment);
						segmentSetOverlap.put(marketsegment, numOfOverlap+1);
					}
					marketSegemntAndOverlap.set(j, segmentSetOverlap);
					
				}
				OverlapDaysList.set(i, marketSegemntAndOverlap);
			}
			
		}
		return OverlapDaysList;
	}

	//create Power set segment
	private static List<Set<MarketSegment>> createPowerSegments(Set<MarketSegment> m_Segements) {
		
		Set<Set<MarketSegment>> segmentPowerSet = PowerSet(m_Segements);
		List<Set<MarketSegment>> segmentPowerSetList = new ArrayList<Set<MarketSegment>>(segmentPowerSet);
		return segmentPowerSetList;
	}

	
	//the creation of power set
	public static <T> Set<Set<T>> PowerSet(Set<T> originalSet) {
	    Set<Set<T>> sets = new HashSet<Set<T>>();
	    if (originalSet.isEmpty()) {
	    	sets.add(new HashSet<T>());
	    	return sets;
	    }
	    List<T> list = new ArrayList<T>(originalSet);
	    T head = list.get(0);
	    Set<T> rest = new HashSet<T>(list.subList(1, list.size())); 
	    for (Set<T> set : PowerSet(rest)) {
	    	Set<T> newSet = new HashSet<T>();
	    	newSet.add(head);
	    	newSet.addAll(set);
	    	sets.add(newSet);
	    	sets.add(set);
	    }		
	    return sets;
	}
	
		//calc the weight of the power set segment of the opportunity segment
	private static int CalcWeightOfPowerSetSegmentPop() {
			int sumWeightOfPowerSet=0;
			for (Set<MarketSegment> marketSegment: m_powerSegments){
				//next line is call to method of class MarketSegemnt
				sumWeightOfPowerSet = MarketSegment.marketSegmentSize(marketSegment);
			}
			return sumWeightOfPowerSet;
		}

*/
	
}
	
