package extras;

import java.util.Map;

import config.GameConstants;


/**The class  allow us save all the UCS bids that were made by us  during the game.
*Using this data that contains the bids properties, 
**status and results allows us to evaluate a new bid and predict its results.
*
*/
public class UCSBid {
	
		public static double getTotalRemaining(Map<Integer, CampaignData> myActiveCampaigns)
		{
			double sum = 0;
			for (CampaignData campaign : myActiveCampaigns.values())
			{
				sum += campaign.getRemainingBudget();
			}
			return sum;
		}
		public static double getTotalImpsToGo(Map<Integer, CampaignData> myActiveCampaigns)
		{
			double sum = 0;
			for (CampaignData campaign : myActiveCampaigns.values())
			{
				sum += campaign.impsTogo();
			}
			return sum;
		}
		
		public static double DetermineUSCBid(double previous_bid_price, double previous_bid_level,Map<Integer, CampaignData> myActiveCampaigns)
		{
			double current_usc_bid;
			double Dailyreach =DailyReach(myActiveCampaigns);
			double ro = Dailyreach * GameConstants.minImp;
			
			if (previous_bid_level>0.9)
			{
				current_usc_bid= (previous_bid_price/(1+GameConstants.GUCS));
			}
			else if(previous_bid_level<0.6561)
				current_usc_bid=previous_bid_price*(1 + GameConstants.GUCSPanic);
			else if ( (previous_bid_level<0.81) && ( (0.1 * ro * (GameConstants.fixedBudgetPrecentege * getTotalRemaining(myActiveCampaigns) /getTotalImpsToGo(myActiveCampaigns))) > GameConstants.GUCS * previous_bid_price)   )
			{
				current_usc_bid=(previous_bid_price*((1+GameConstants.GUCS)));			
			}
			
			else 
				current_usc_bid=previous_bid_price;
			
			return current_usc_bid;
		}
		
		public static double DailyReach(Map<Integer, CampaignData> myActiveCampaigns)
		{
			double sum=0;
			long reach ;
			long days;
			long start;
			long end;
			for (Map.Entry<Integer, CampaignData> campaign : myActiveCampaigns.entrySet())
			{
				reach= campaign.getValue().getreachImps();
				start= campaign.getValue().getdayStart();
				end=campaign.getValue().getdayEnd();
				days=end-start;
				
				sum = sum +(reach/ days);
			}
			return sum;
		}
}

