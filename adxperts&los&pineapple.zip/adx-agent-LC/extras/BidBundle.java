package extras;


import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import config.GameConstants;
import edu.umich.eecs.tac.props.Ad;
import extras.CampaignData;
import tau.tac.adx.ads.properties.AdType;
import tau.tac.adx.devices.Device;
import tau.tac.adx.props.AdxBidBundle;
import tau.tac.adx.props.AdxQuery;
import tau.tac.adx.report.adn.MarketSegment;


/** This class is designed to override the given SendBidsAndAds(Map<Integer, CampaignData> myCampaigns) function and to provide all relevant functions in order to achieve that.
*
* To be used by the agent in function handleSimulationStatus() in the following way: BidBundle.sendBidsAndAds()
*
*
*
*
*/
public class BidBundle 
{

	public static boolean isCampaignActive(CampaignData campaign,int day) 
	{
		int dayBiddingFor = day + 1;
		if ((dayBiddingFor >= campaign.getdayStart())
				&& (dayBiddingFor <= campaign.getdayEnd())
				&& (campaign.impsTogo() > 0)) {
			return true;
		}
		return false;
	}
	public static AdxBidBundle sendBidAndAds(Map<Integer, CampaignData> myCampaigns,int day) 
	{

		AdxBidBundle bidBundle = new AdxBidBundle();
		
		Map< Set<MarketSegment>, Set<CampaignData> > amountBySegments = new HashMap<Set<MarketSegment>, Set<CampaignData> >();
		Map<CampaignData, Integer> ratios = new HashMap<CampaignData, Integer>();
		
		//sorting campaings according to segments
		for (CampaignData campaign : myCampaigns.values()) 
		{
			if (isCampaignActive(campaign, day)) 
			{
				Set<MarketSegment> key = campaign.gettargetSegment();
				Set<CampaignData> set = amountBySegments.get(key); 
				if (set == null) 
				{
					set = new HashSet<CampaignData>();
					amountBySegments.put(key, set);
				}
				set.add(campaign);
				amountBySegments.put(key,set);
				ratios.put(campaign,1);
			}
		}
		
		//setting the weight for the each campaign
		for(Set<MarketSegment> segment : amountBySegments.keySet())
		{
			Set<CampaignData> set = amountBySegments.get(segment);
			Iterator<CampaignData> iter=set.iterator();
			if(set.size() == 1)
				continue;
			else
			{	
				int sum=0;
				while(iter.hasNext())
				{
					CampaignData campaign = iter.next();
					sum += campaign.getRatioTillFinish();
				}
				for(CampaignData campaign : set)
					//continue;
					ratios.put(campaign, (int)(campaign.getRatioTillFinish()*10 / sum));
			}	
		}

		
		//making the actual bid bundle for each campaign
		double budget;
		double rbid = 0;
		long reachImps;
		long impsToGo;
		double impsRatio;
		double impsRatioTillFinish;
		int panic;
		long impressionLimit;
		double budgetLimit;
		
		for (CampaignData campaign : myCampaigns.values()) 
		{
			if (isCampaignActive(campaign,day)) 
			{ 
				if (campaign.daysTogo(day)<=0){
					continue;
				}
				budget = campaign.getRemainingBudget() * GameConstants.fixedBudgetPrecentege;
				System.out.println(" campaign: "+campaign.id + " remaining budget: " + campaign.getRemainingBudget());
				reachImps = campaign.getreachImps();
				impsToGo = campaign.impsTogo();
				impsRatio = campaign.getImpressionRatio();
				impsRatioTillFinish = campaign.getRatioTillFinish();
				panic = 0;
							
				if ((campaign.daysTogo(day) < campaign.getLength() * GameConstants.panicDays)&&(impsRatioTillFinish > impsRatio))
				{
					panic = 1;
					budget = budget * 2; //campaign is in panic mode, increase budget
					int t = ratios.get(campaign);
					ratios.put(campaign, t + GameConstants.panicRatio); //campaign is in panic mode, increase weight
					System.out.println("LosCaparos insert to panic mode at campaign: "+campaign.id);
				}
				else if (((impsToGo / reachImps) <= GameConstants.smallReach)&&(budget <= GameConstants.tooLittleBudget * campaign.getBudget())){
					budget = budget * GameConstants.maxCampaignCostByImpression; //campaign is lost, shrink budget to minimize losses
					System.out.println("LosCaparos is abandoning campaign: "+campaign.id);
				}
				else{
					System.out.println("LosCaparos is having a regular bidbundle for campaign : " +campaign.id);
				}
				rbid = budget / impsToGo ; //initial rbid calculation
							
				int entCount = 0;
				for (AdxQuery query : campaign.getCampaignQueries()) 
				{
					
					if (campaign.impsTogo() - entCount > 0) 
					{
						double tbid = rbid;
						if (query.getDevice() == Device.pc) 
						{
							if (query.getAdType() == AdType.text) 
								entCount++;
							else 
							{
								entCount ++;
								tbid = campaign.getvideoCoef()*rbid;
							}
						} 
						else 
						{
							if (query.getAdType() == AdType.text) 
							{
								entCount++;
								tbid = campaign.getmobileCoef()*rbid;
							} 
							else 
							{
								entCount++;
								tbid = (campaign.getmobileCoef()+campaign.getvideoCoef())*rbid;
							}

						}
						System.out.println(" for campaign : " +campaign.id + "the bid is: "+ tbid);
						bidBundle.addQuery(query, tbid, new Ad(null),campaign.getId(), ratios.get(campaign));
					}
				}
				
				if (panic == 1)
				{
					impressionLimit = impsToGo;
					budgetLimit = GameConstants.budgetLimit * budget;
				}
				else
				{
					impressionLimit = impsToGo;//GameConstants.budgetLimit * reachImps - reachImps + impsToGo;
					budgetLimit =  budget;
				}


				System.out.println("++ Day: " + day +
						" Campaign id: " + campaign.getId() +
						" imps limit: " + impressionLimit +
						" budgetLimit: " + budgetLimit);

				bidBundle.setCampaignDailyLimit(campaign.getId(), (int)impressionLimit, budgetLimit);

				System.out.println("Day " + day + ": Updated " + entCount + " Bid Bundle entries for Campaign id " + campaign.getId());
			}
		}
		return bidBundle;
	}
}