

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedList;
import java.util.Map;
import java.util.Queue;
import java.util.Random;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import se.sics.isl.transport.Transportable;
import se.sics.tasim.aw.Agent;
import se.sics.tasim.aw.Message;
import se.sics.tasim.props.SimulationStatus;
import se.sics.tasim.props.StartInfo;
import tau.tac.adx.ads.properties.AdType;
import tau.tac.adx.demand.CampaignStats;
import tau.tac.adx.devices.Device;
import tau.tac.adx.props.AdxBidBundle;
import tau.tac.adx.props.AdxQuery;
import tau.tac.adx.props.PublisherCatalog;
import tau.tac.adx.props.PublisherCatalogEntry;
import tau.tac.adx.props.ReservePriceInfo;
import tau.tac.adx.report.adn.AdNetworkReport;
import tau.tac.adx.report.adn.MarketSegment;
import tau.tac.adx.report.demand.AdNetBidMessage;
import tau.tac.adx.report.demand.AdNetworkDailyNotification;
import tau.tac.adx.report.demand.CampaignOpportunityMessage;
import tau.tac.adx.report.demand.CampaignReport;
import tau.tac.adx.report.demand.CampaignReportKey;
import tau.tac.adx.report.demand.InitialCampaignMessage;
import tau.tac.adx.report.demand.campaign.auction.CampaignAuctionReport;
import tau.tac.adx.report.publisher.AdxPublisherReport;
import tau.tac.adx.report.publisher.AdxPublisherReportEntry;
import edu.umich.eecs.tac.props.BankStatus;
import extras.CampaignData;
import extras.Cobe;
import extras.BidBundle;
import extras.UCSBid;
import config.GameConstants;
/**
 * 
 * @author Mariano Schain
 * Test plug-in
 * 
 */
public class LosCaparos extends Agent {

	private final Logger log = Logger
			.getLogger(LosCaparos.class.getName());
	
	/*==========================================================
	 * 						variables 
	 ===========================================================*/

	/**
	 * Basic simulation information. An agent should receive the {@link
	 * StartInfo} at the beginning of the game or during recovery.
	 **/
	@SuppressWarnings("unused")
	private StartInfo startInfo;

	/**
	 * Messages received:
	 * 
	 * We keep all the {@link CampaignReport campaign reports} delivered to the
	 * agent. We also keep the initialization messages {@link PublisherCatalog}
	 * and {@link InitialCampaignMessage} and the most recent messages and
	 * reports {@link CampaignOpportunityMessage}, {@link CampaignReport}, and
	 * {@link AdNetworkDailyNotification}.
	 */
	private final Queue<CampaignReport> campaignReports;
	private PublisherCatalog publisherCatalog;
	private InitialCampaignMessage initialCampaignMessage;
	private AdNetworkDailyNotification adNetworkDailyNotification;

	/**
	 * The addresses of server entities to which the agent should send the daily
	 * bids data
	 **/
	private String demandAgentAddress;
	
	private String adxAgentAddress;
	
	private int numOfCampaigns = 0; //The number of campaigns we won - maybe not necessary.
	
	private double MyCurrRating=1.0; //The current rating of the agent 

	/**
	 * we maintain a list of queries - each characterized by the web site (the
	 * publisher), the device type, the ad type, and the user market segment
	 **/
	private AdxQuery[] queries;

	private CampaignData pendingCampaign; /**Information regarding the latest campaign opportunity announced**/

	public Map<Integer, CampaignData> myCampaigns; /**A collection (mapped by the campaign id) of the campaigns won**/

	public Map<Integer, CampaignData> ActiveCampaigns = new HashMap<Integer, CampaignData>(); /**A collection (mapped by the campaign id) of all the active campaigns in the game**/
	
	public Map<Integer, CampaignData> myActiveCampaigns = new HashMap<Integer, CampaignData>();/**A collection (mapped by the campaign id) of all the active campaigns the agent won**/
	
	private AdxBidBundle bidBundle; /**the bidBundle to be sent daily to the AdX **/

	public double currUcsBid; /**The current bid for the user classification service**/
	
	public double lastCampaignBid; /**The current bid for the user classification service**/

	public double ucsTargetLevel; /**The targeted service level for the user classification service**/
	
	/* current day of simulation*/
	
	private int day; /**current day**/
	
	private String[] publisherNames; /**active publishers in the game**/
	
	private CampaignData currCampaign;/**the current campaign**/ //maybe not necessary.
	
	private CampaignData lastCampaignOpportunity;
	
	//private Map<String, WebSite> WebSites;//moran
	//public static CampaignData[] AllCampaignBids = new CampaignData[60];//moran
	//public static UCSBid[] UscBidsArray = new UCSBid[60];//moran
	
	
	public LosCaparos() {
		campaignReports = new LinkedList<CampaignReport>();
	}

	
	/*==========================================================
	 * 						Handlers 
	 ===========================================================*/
	
	@Override
	protected void messageReceived(Message message) {
		try {
			Transportable content = message.getContent();

			// log.fine(message.getContent().getClass().toString());

			if (content instanceof InitialCampaignMessage) {
				handleInitialCampaignMessage((InitialCampaignMessage) content);
			} else if (content instanceof CampaignOpportunityMessage) {
				handleICampaignOpportunityMessage((CampaignOpportunityMessage) content);
			} else if (content instanceof CampaignReport) {
				handleCampaignReport((CampaignReport) content);
			} else if (content instanceof AdNetworkDailyNotification) {
				handleAdNetworkDailyNotification((AdNetworkDailyNotification) content);
			} else if (content instanceof AdxPublisherReport) {
				handleAdxPublisherReport((AdxPublisherReport) content);
			} else if (content instanceof SimulationStatus) {
				handleSimulationStatus((SimulationStatus) content);
			} else if (content instanceof PublisherCatalog) {
				handlePublisherCatalog((PublisherCatalog) content);
			} else if (content instanceof AdNetworkReport) {
				handleAdNetworkReport((AdNetworkReport) content);
			} else if (content instanceof StartInfo) {
				handleStartInfo((StartInfo) content);
			} else if (content instanceof BankStatus) {
				handleBankStatus((BankStatus) content);
			} else if(content instanceof CampaignAuctionReport) {
				hadnleCampaignAuctionReport((CampaignAuctionReport) content);
			} else if (content instanceof ReservePriceInfo) {
				// ((ReservePriceInfo)content).getReservePriceType();
			} else {
				System.out.println("UNKNOWN Message Received: " + content);
			}

		} catch (NullPointerException e) {
			this.log.log(Level.SEVERE,
					"Exception thrown while trying to parse message." + e);
			return;
		}
	}

	private void hadnleCampaignAuctionReport(CampaignAuctionReport content) {
		// ingoring - this message is obsolete
	}

	private void handleBankStatus(BankStatus content) {
		System.out.println("Day " + day + " :" + content.toString());
	}

	/**
	 * Processes the start information.
	 * 
	 * @param startInfo
	 *            the start information.
	 */
	protected void handleStartInfo(StartInfo startInfo) {
		this.startInfo = startInfo;
	}

	/**
	 * Process the reported set of publishers
	 * 
	 * @param publisherCatalog
	 */
	private void handlePublisherCatalog(PublisherCatalog publisherCatalog) {
		this.publisherCatalog = publisherCatalog;
		generateAdxQuerySpace();
		getPublishersNames();

	}

	/**
	 * On day 0, a campaign (the "initial campaign") is allocated to each
	 * competing agent. The campaign starts on day 1. The address of the
	 * server's AdxAgent (to which bid bundles are sent) and DemandAgent (to
	 * which bids regarding campaign opportunities may be sent in subsequent
	 * days) are also reported in the initial campaign message
	 */
	private void handleInitialCampaignMessage(
			InitialCampaignMessage campaignMessage) {
		System.out.println(campaignMessage.toString());

		day = 0;

		initialCampaignMessage = campaignMessage;
		demandAgentAddress = campaignMessage.getDemandAgentAddress();
		adxAgentAddress = campaignMessage.getAdxAgentAddress();

		CampaignData campaignData = new CampaignData(initialCampaignMessage);
		campaignData.setBudget(initialCampaignMessage.getBudgetMillis()/1000.0);
		campaignData.setRemainingBudget((initialCampaignMessage.getBudgetMillis()/1000.0));
		campaignData.setMyBid(initialCampaignMessage.getBudgetMillis());//on the first day we get the campaign "randomly" so it's like the budget equals our bid
		campaignData.setIsWin(true);//update the we won this campaign
		campaignData.setMyRating(1.0);//our initial rating
		campaignData.setSegmentSize();
		currCampaign = campaignData;
		genCampaignQueries(currCampaign);

		/*
		 * The initial campaign is already allocated to our agent so we add it
		 * to our allocated-campaigns list.
		 */
		System.out.println("Day " + day + ": Allocated campaign - " + campaignData);
		myCampaigns.put(initialCampaignMessage.getId(), campaignData);
		myActiveCampaigns.put(initialCampaignMessage.getId(), campaignData);
		ActiveCampaigns.put(initialCampaignMessage.getId(), campaignData);
		numOfCampaigns = 1; /*LOSCAPAROS*/
	}

	/**
	 * On day n ( > 0) a campaign opportunity is announced to the competing
	 * agents. The campaign starts on day n + 2 or later and the agents may send
	 * (on day n) related bids (attempting to win the campaign). The allocation
	 * (the winner) is announced to the competing agents during day n + 1.
	 */
	private void handleICampaignOpportunityMessage(
			CampaignOpportunityMessage com) {

		day = com.getDay();

		pendingCampaign = new CampaignData(com);
		//pendingCampaignBid = new CampaignBid(com);//moran
		System.out.println("Day " + day + ": Campaign opportunity - " + pendingCampaign);

		/*
		 * The campaign requires com.getReachImps() impressions. The competing
		 * Ad Networks bid for the total campaign Budget (that is, the ad
		 * network that offers the lowest budget gets the campaign allocated).
		 * The advertiser is willing to pay the AdNetwork at most 1$ CPM,
		 * therefore the total number of impressions may be treated as a reserve
		 * (upper bound) price for the auction.
		 */
		
		
		/*calling to Omer function*/
		long cmpBidMillis = Cobe.CalcPayment(pendingCampaign, myActiveCampaigns,ActiveCampaigns,day,lastCampaignOpportunity,MyCurrRating); //compute new bid to submit)
		lastCampaignBid = cmpBidMillis;
		lastCampaignOpportunity = pendingCampaign;
		lastCampaignOpportunity.setMyBid(lastCampaignBid);
		System.out.println("Day " + day + ": Campaign total budget bid (millis): " + cmpBidMillis);

		/*
		 * Adjust ucs bid s.t. target level is achieved. Note: The bid for the
		 * user classification service is piggybacked
		 */

		/*calling to Moran function*/
		
		if (day==0){
			currUcsBid = GameConstants.initalUCSBid;
		}
		else{
			currUcsBid = UCSBid.DetermineUSCBid(currUcsBid, ucsTargetLevel, myActiveCampaigns);
		}
		
		
		/* Note: Campaign bid is in millis */
		AdNetBidMessage bids = new AdNetBidMessage(currUcsBid, pendingCampaign.getId(), cmpBidMillis);
		sendMessage(demandAgentAddress, bids);
	}

	/**
	 * On day n ( > 0), the result of the UserClassificationService and Campaign
	 * auctions (for which the competing agents sent bids during day n -1) are
	 * reported. The reported Campaign starts in day n+1 or later and the user
	 * classification service level is applicable starting from day n+1.
	 */
	private void handleAdNetworkDailyNotification(
			AdNetworkDailyNotification notificationMessage) {

		adNetworkDailyNotification = notificationMessage;

		System.out.println("Day " + day + ": Daily notification for campaign "
				+ adNetworkDailyNotification.getCampaignId());

		String campaignAllocatedTo = " allocated to "
				+ notificationMessage.getWinner();
		
		MyCurrRating=notificationMessage.getQualityScore();//moran
		ucsTargetLevel=notificationMessage.getServiceLevel();//moran

		if ((pendingCampaign.getId() == adNetworkDailyNotification.getCampaignId())
				&& (notificationMessage.getCostMillis() != 0)) {

			/* add campaign to list of won campaigns */
			pendingCampaign.setBudget(notificationMessage.getCostMillis()/1000.0);
			pendingCampaign.setRemainingBudget(notificationMessage.getCostMillis()/1000.0);
			pendingCampaign.setMyBid(lastCampaignBid);//update the bid we gave for the campaign
			pendingCampaign.setIsWin(true);//update the we won this campaign
			pendingCampaign.setMyRating(MyCurrRating);//our initial rating
			pendingCampaign.setSegmentSize();
			currCampaign = pendingCampaign;
			genCampaignQueries(currCampaign);
			myCampaigns.put(pendingCampaign.getId(), pendingCampaign);
			myActiveCampaigns.put(pendingCampaign.getId(), pendingCampaign);
			numOfCampaigns=numOfCampaigns+1; /*LOSCAPAROS*/
			campaignAllocatedTo = " WON at cost (Millis)"
					+ notificationMessage.getCostMillis();
		}
		pendingCampaign.setSegmentSize();
		ActiveCampaigns.put(pendingCampaign.getId(), pendingCampaign); //insert to active campaigns list
		
		updateActiveCampaigns(); //update the Map and remove inactive campaigns 
		updatemyActiveCampaigns();//update the Map and remove inactive campaigns 
		
		//UscBidsArray[day-1].setUCSLevel(ucsTargetLevel);//moran
		//UscBidsArray[day-1].setActualPaiment(notificationMessage.getPrice());//moran
		//double compbid = notificationMessage.getPrice()/ucsTargetLevel;//moran
		//UscBidsArray[day-1].setCompetitorBid(compbid);//moran
		
		System.out.println("Day " + day + ": " + campaignAllocatedTo
				+ ". UCS Level set to " + notificationMessage.getServiceLevel()
				+ " at price " + notificationMessage.getPrice()
				+ " Quality Score is: " + MyCurrRating);
	}

	/**
	 * The SimulationStatus message received on day n indicates that the
	 * calculation time is up and the agent is requested to send its bid bundle
	 * to the AdX.
	 */
	private void handleSimulationStatus(SimulationStatus simulationStatus) {
		System.out.println("Day " + day + " : Simulation Status Received");
		sendBidAndAds();
		System.out.println("Day " + day + " ended. Starting next day");
		++day;
	}

	/**
	 * 
	 */
	protected void sendBidAndAds() {

		bidBundle = BidBundle.sendBidAndAds(myCampaigns,day);
		if (bidBundle != null) {
			System.out.println("Day " + day + ": Sending BidBundle");
			sendMessage(adxAgentAddress, bidBundle);
		}
	}

	/**
	 * Campaigns performance w.r.t. each allocated campaign
	 */
	private void handleCampaignReport(CampaignReport campaignReport) {

		campaignReports.add(campaignReport);

		/*
		 * for each campaign, the accumulated statistics from day 1 up to day
		 * n-1 are reported
		 */
		for (CampaignReportKey campaignKey : campaignReport.keys()) {
			int cmpId = campaignKey.getCampaignId();
			CampaignStats cstats = campaignReport.getCampaignReportEntry(
					campaignKey).getCampaignStats();
			myCampaigns.get(cmpId).setStats(cstats);
			myCampaigns.get(cmpId).setRatios(day); //update campaign ratio according to stats
			myCampaigns.get(cmpId).setRemainingBudget(myCampaigns.get(cmpId).getRemainingBudget() - cstats.getCost());
			System.out.println("Day " + day + ": Updating campaign " + cmpId + " stats: "
					+ cstats.getTargetedImps() + " tgtImps "
					+ cstats.getOtherImps() + " nonTgtImps. Cost of imps is "
					+ cstats.getCost());
		}
	}

	/**
	 * Users and Publishers statistics: popularity and ad type orientation
	 */
	private void handleAdxPublisherReport(AdxPublisherReport adxPublisherReport) {
		System.out.println("Publishers Report: ");
		for (PublisherCatalogEntry publisherKey : adxPublisherReport.keys()) {
			AdxPublisherReportEntry entry = adxPublisherReport
					.getEntry(publisherKey);
			System.out.println(entry.toString());
		}
	}

	/**
	 * 
	 * @param AdNetworkReport
	 */
	private void handleAdNetworkReport(AdNetworkReport adnetReport) {

		System.out.println("Day " + day + " : AdNetworkReport");
		/*
		 * for (AdNetworkKey adnetKey : adnetReport.keys()) {
		 * 
		 * double rnd = Math.random(); if (rnd > 0.95) { AdNetworkReportEntry
		 * entry = adnetReport .getAdNetworkReportEntry(adnetKey);
		 * System.out.println(adnetKey + " " + entry); } }
		 */
	}

	
	@Override
	protected void simulationSetup() {
		Random random = new Random();
		day = 0;
		bidBundle = new AdxBidBundle();

		/* initial bid between 0.1 and 0.2 */
		currUcsBid = 0.1 + random.nextDouble()/10.0;

		myCampaigns = new HashMap<Integer, CampaignData>();
		log.fine("AdNet " + getName() + " simulationSetup");
	}

	
	@Override
	protected void simulationFinished() {
		campaignReports.clear();
		bidBundle = null;
	}

	/**
	 * A user visit to a publisher's web-site results in an impression
	 * opportunity (a query) that is characterized by the the publisher, the
	 * market segment the user may belongs to, the device used (mobile or
	 * desktop) and the ad type (text or video).
	 * 
	 * An array of all possible queries is generated here, based on the
	 * publisher names reported at game initialization in the publishers catalog
	 * message
	 */
	private void generateAdxQuerySpace() {
		if (publisherCatalog != null && queries == null) {
			Set<AdxQuery> querySet = new HashSet<AdxQuery>();

			/*
			 * for each web site (publisher) we generate all possible variations
			 * of device type, ad type, and user market segment
			 */
			for (PublisherCatalogEntry publisherCatalogEntry : publisherCatalog) {
				String publishersName = publisherCatalogEntry
						.getPublisherName();
				for (MarketSegment userSegment : MarketSegment.values()) {
					Set<MarketSegment> singleMarketSegment = new HashSet<MarketSegment>();
					singleMarketSegment.add(userSegment);

					querySet.add(new AdxQuery(publishersName,
							singleMarketSegment, Device.mobile, AdType.text));

					querySet.add(new AdxQuery(publishersName,
							singleMarketSegment, Device.pc, AdType.text));

					querySet.add(new AdxQuery(publishersName,
							singleMarketSegment, Device.mobile, AdType.video));

					querySet.add(new AdxQuery(publishersName,
							singleMarketSegment, Device.pc, AdType.video));

				}

				/**
				 * An empty segments set is used to indicate the "UNKNOWN"
				 * segment such queries are matched when the UCS fails to
				 * recover the user's segments.
				 */
				querySet.add(new AdxQuery(publishersName,
						new HashSet<MarketSegment>(), Device.mobile,
						AdType.video));
				querySet.add(new AdxQuery(publishersName,
						new HashSet<MarketSegment>(), Device.mobile,
						AdType.text));
				querySet.add(new AdxQuery(publishersName,
						new HashSet<MarketSegment>(), Device.pc, AdType.video));
				querySet.add(new AdxQuery(publishersName,
						new HashSet<MarketSegment>(), Device.pc, AdType.text));
			}
			queries = new AdxQuery[querySet.size()];
			querySet.toArray(queries);
		}
	}
	
	/*genarates an array of the publishers names
	 * */
	private void getPublishersNames() {
		if (null == publisherNames && publisherCatalog != null) {
			ArrayList<String> names = new ArrayList<String>();
			for (PublisherCatalogEntry pce : publisherCatalog) {
				names.add(pce.getPublisherName());
			}

			publisherNames = new String[names.size()];
			names.toArray(publisherNames);
			//InitWebSites();
			//for (String name: publisherNames){
				//WebSites.get(name).setIsActive(true);
			//}
		}
	}
	

	
	/*
	 * genarates the campaign queries relevant for the specific campaign, and assign them as the campaigns campaignQueries field 
	 */
	private void genCampaignQueries(CampaignData campaignData) {
		Set<AdxQuery> campaignQueriesSet = new HashSet<AdxQuery>();
		for (String PublisherName : publisherNames) {
			campaignQueriesSet.add(new AdxQuery(PublisherName,
					campaignData.gettargetSegment(), Device.mobile, AdType.text));
			campaignQueriesSet.add(new AdxQuery(PublisherName,
					campaignData.gettargetSegment(), Device.mobile, AdType.video));
			campaignQueriesSet.add(new AdxQuery(PublisherName,
					campaignData.gettargetSegment(), Device.pc, AdType.text));
			campaignQueriesSet.add(new AdxQuery(PublisherName,
					campaignData.gettargetSegment(), Device.pc, AdType.video));
		}

		campaignData.setCampaignQueries(new AdxQuery[campaignQueriesSet.size()]);
		campaignQueriesSet.toArray(campaignData.getCampaignQueries());
		System.out.println("!!!!!!!!!!!!!!!!!!!!!!"+Arrays.toString(campaignData.getCampaignQueries())+"!!!!!!!!!!!!!!!!");
		

	}
	
	
	private void updateActiveCampaigns(){
		Set<Integer> campaignsToRemove = new HashSet<Integer>();
		if (ActiveCampaigns.size()>0){
			for (Map.Entry<Integer, CampaignData> campaign : ActiveCampaigns.entrySet())
			{
				if (campaign.getValue().getdayEnd()<day){
					campaignsToRemove.add(campaign.getKey());
				}
			}
			if (campaignsToRemove.size()>0){
				for (Integer campaignID: campaignsToRemove){
					ActiveCampaigns.remove(campaignID);
				}
			}
		}
	}
	
	private void updatemyActiveCampaigns() {
		Set<Integer> campaignsToRemove = new HashSet<Integer>();
		if (myActiveCampaigns.size()>0){
			for (Map.Entry<Integer, CampaignData> campaign : myActiveCampaigns.entrySet())
			{
				if (campaign.getValue().getdayEnd()<day){
					campaignsToRemove.add(campaign.getKey());
				}
			}
			if (campaignsToRemove.size()>0){
				for (Integer campaignID: campaignsToRemove){
					myActiveCampaigns.remove(campaignID);
				}
			}
		}
	}
	

	/*=============NOT IN USE=============================*/
	/*	
	private class UCSBid { //moran
		double MyUCSBid;
		double UCSLevel;
		double ActualPaiment;
		double CompetitorBid;
		//int NumOfActiveCampains;
	
		public UCSBid(double bid) {
			MyUCSBid=bid;
			UCSLevel=0.0;
			ActualPaiment=0.0;
			CompetitorBid=0.0;
		}

		public void setUCSLevel(double level) {
			UCSLevel = level;
		}
		public void setActualPaiment(double paiment) {
			ActualPaiment = paiment;
		}
		public void setCompetitorBid(double comp) {
			CompetitorBid = comp;
		}
		
		public double getMyUCSBid() {
			return MyUCSBid;
		}
		
		public double getUCSLevel() {
			return UCSLevel;
		}
		public double getActualPaiment() {
			return ActualPaiment;
		}
		public double getCompetitorBid() {
			return CompetitorBid;
		}
	}
	
	

	private class WebSite { //moran
		String WebName;
		double Popularity;
		Map<String, Double> AgeDidtribution;
		Map<String, Double> IncomeDidtribution;
		double Male;
		double mobile;
		boolean IsActive;
		int[] video;
		int[] text;
	
		public WebSite(String WebName,double Popularity,
				Map<String, Double> AgeDidtribution,Map<String, Double> IncomeDidtribution,double Male,double mobile) {
			WebName=WebName;
			AgeDidtribution=AgeDidtribution;
			IncomeDidtribution= IncomeDidtribution;
			Male=Male;
			mobile=mobile;
			IsActive=false;
			video=new int[60];
			text=new int[60];
		}

		public void setVideo(int Video,int day) {
			video[day] = Video;
		}
		public void setIsActive(boolean Active) {
			IsActive = Active;
		}
		public void setText(int Text,int day) {
			text[day] = Text;
		}
		public String getWebName() {
			return WebName;
		}
		
		public double getPopularity() {
			return Popularity;
		}
		public Map<String, Double> getAgeDidtribution() {
			return AgeDidtribution;
		}
		public double getMale() {
			return Male;
		}
		public double getmobile() {
			return mobile;
		}
		public int[] getvideo() {
			return video;
		}
		public int[] gettext() {
			return text;
		}
		public boolean getIsActive() {
			return IsActive ;
		}
	}
		private void InitWebSites() {
		WebSites=new HashMap<String,WebSite>();
		
		Map<String, Double> YahooAgeMap = new HashMap<String,Double>();
		Map<String, Double> YahooIncomeMap = new HashMap<String,Double>();
		Map<String, Double> CNNAgeMap = new HashMap<String,Double>();
		Map<String, Double> CNNIncomeMap = new HashMap<String,Double>();
		Map<String, Double> NYTimesAgeMap = new HashMap<String,Double>();
		Map<String, Double> NYTimesIncomeMap = new HashMap<String,Double>();
		Map<String, Double> HfngtnAgeMap = new HashMap<String,Double>();
		Map<String, Double> HfngtnIncomeMap = new HashMap<String,Double>();
		Map<String, Double> MSNAgeMap = new HashMap<String,Double>();
		Map<String, Double> MSNIncomeMap = new HashMap<String,Double>();
		Map<String, Double> FoxAgeMap = new HashMap<String,Double>();
		Map<String, Double> FoxIncomeMap = new HashMap<String,Double>();
		Map<String, Double> AmazonAgeMap = new HashMap<String,Double>();
		Map<String, Double> AmazonIncomeMap = new HashMap<String,Double>();
		Map<String, Double> EbayAgeMap = new HashMap<String,Double>();
		Map<String, Double> EbayIncomeMap = new HashMap<String,Double>();
		Map<String, Double> WalMartAgeMap = new HashMap<String,Double>();
		Map<String, Double> WalMartIncomeMap = new HashMap<String,Double>();
		Map<String, Double> TargetAgeMap = new HashMap<String,Double>();
		Map<String, Double> TargetIncomeMap = new HashMap<String,Double>();
		Map<String, Double> BestBuyAgeMap = new HashMap<String,Double>();
		Map<String, Double> BestBuyIncomeMap = new HashMap<String,Double>();
		Map<String, Double> SearsAgeMap = new HashMap<String,Double>();
		Map<String, Double> SearsIncomeMap = new HashMap<String,Double>();
		Map<String, Double> WebMDAgeMap = new HashMap<String,Double>();
		Map<String, Double> WebMDIncomeMap = new HashMap<String,Double>();
		Map<String, Double> EhowAgeMap = new HashMap<String,Double>();
		Map<String, Double> EhowIncomeMap = new HashMap<String,Double>();
		Map<String, Double> AskAgeMap = new HashMap<String,Double>();
		Map<String, Double> AskIncomeMap = new HashMap<String,Double>();
		Map<String, Double> TripAdvisorAgeMap = new HashMap<String,Double>();
		Map<String, Double> TripAdvisorIncomeMap = new HashMap<String,Double>();
		Map<String, Double> CNetAgeMap = new HashMap<String,Double>();
		Map<String, Double> CNetIncomeMap = new HashMap<String,Double>();
		Map<String, Double> WeatherAgeMap = new HashMap<String,Double>();
		Map<String, Double> WeatherIncomeMap = new HashMap<String,Double>();
		
		
		YahooAgeMap.put("18-24",12.2);
		YahooAgeMap.put("25-34",17.1);
		YahooAgeMap.put("35-44",16.7);
		YahooAgeMap.put("45-54",18.4);
		YahooAgeMap.put("55-64",16.4);
		YahooIncomeMap.put("0-30",53.0);
		YahooIncomeMap.put("36-60",27.0);
		YahooIncomeMap.put("60-100",13.0);
		
		CNNAgeMap.put("18-24",10.2);
		CNNAgeMap.put("25-34",16.1);
		CNNAgeMap.put("35-44",16.7);
		CNNAgeMap.put("45-54",19.4);
		CNNAgeMap.put("55-64",17.4);
		CNNIncomeMap.put("0-30",48.0);
		CNNIncomeMap.put("36-60",27.0);
		CNNIncomeMap.put("60-100",16.0);		
		
		NYTimesAgeMap.put("18-24",9.2);
		NYTimesAgeMap.put("25-34",15.1);
		NYTimesAgeMap.put("35-44",16.7);
		NYTimesAgeMap.put("45-54",19.4);
		NYTimesAgeMap.put("55-64",17.4);
		NYTimesIncomeMap.put("0-30",47.0);
		NYTimesIncomeMap.put("36-60",26.0);
		NYTimesIncomeMap.put("60-100",17.0);
		
		HfngtnAgeMap.put("18-24",10.2);
		HfngtnAgeMap.put("25-34",16.1);
		HfngtnAgeMap.put("35-44",16.7);
		HfngtnAgeMap.put("45-54",19.4);
		HfngtnAgeMap.put("55-64",17.4);
		HfngtnIncomeMap.put("0-30",47.0);
		HfngtnIncomeMap.put("36-60",27.0);
		HfngtnIncomeMap.put("60-100",17.0);
		
		MSNAgeMap.put("18-24",10.2);
		MSNAgeMap.put("25-34",16.1);
		MSNAgeMap.put("35-44",16.7);
		MSNAgeMap.put("45-54",19.4);
		MSNAgeMap.put("55-64",17.4);
		MSNIncomeMap.put("0-30",49.0);
		MSNIncomeMap.put("36-60",27.0);
		MSNIncomeMap.put("60-100",16.0);
		
		FoxAgeMap.put("18-24",9.2);
		FoxAgeMap.put("25-34",15.1);
		FoxAgeMap.put("35-44",16.7);
		FoxAgeMap.put("45-54",19.4);
		FoxAgeMap.put("55-64",18.4);
		FoxIncomeMap.put("0-30",46.0);
		FoxIncomeMap.put("36-60",26.0);
		FoxIncomeMap.put("60-100",18.0);
		
		AmazonAgeMap.put("18-24",9.2);
		AmazonAgeMap.put("25-34",15.1);
		AmazonAgeMap.put("35-44",16.7);
		AmazonAgeMap.put("45-54",19.4);
		AmazonAgeMap.put("55-64",18.4);
		AmazonIncomeMap.put("0-30",50.0);
		AmazonIncomeMap.put("36-60",27.0);
		AmazonIncomeMap.put("60-100",15.0);
		
		EbayAgeMap.put("18-24",9.2);
		EbayAgeMap.put("25-34",16.1);
		EbayAgeMap.put("35-44",15.7);
		EbayAgeMap.put("45-54",19.4);
		EbayAgeMap.put("55-64",17.4);
		EbayIncomeMap.put("0-30",50.0);
		EbayIncomeMap.put("36-60",27.0);
		EbayIncomeMap.put("60-100",15.0);
		
		WalMartAgeMap.put("18-24",7.2);
		WalMartAgeMap.put("25-34",15.1);
		WalMartAgeMap.put("35-44",16.7);
		WalMartAgeMap.put("45-54",20.4);
		WalMartAgeMap.put("55-64",18.4);
		WalMartIncomeMap.put("0-30",47.0);
		WalMartIncomeMap.put("36-60",28.0);
		WalMartIncomeMap.put("60-100",19.0);
		
		TargetAgeMap.put("18-24",9.2);
		TargetAgeMap.put("25-34",17.1);
		TargetAgeMap.put("35-44",17.7);
		TargetAgeMap.put("45-54",18.4);
		TargetAgeMap.put("55-64",17.4);
		TargetIncomeMap.put("0-30",45.0);
		TargetIncomeMap.put("36-60",27.0);
		TargetIncomeMap.put("60-100",19.0);
		
		BestBuyAgeMap.put("18-24",10.2);
		BestBuyAgeMap.put("25-34",14.1);
		BestBuyAgeMap.put("35-44",16.7);
		BestBuyAgeMap.put("45-54",20.4);
		BestBuyAgeMap.put("55-64",17.4);
		BestBuyIncomeMap.put("0-30",46.5);
		BestBuyIncomeMap.put("36-60",26.0);
		BestBuyIncomeMap.put("60-100",18.0);
		
		SearsAgeMap.put("18-24",9.2);
		SearsAgeMap.put("25-34",12.1);
		SearsAgeMap.put("35-44",16.7);
		SearsAgeMap.put("45-54",20.4);
		SearsAgeMap.put("55-64",18.4);
		SearsIncomeMap.put("0-30",45.0);
		SearsIncomeMap.put("36-60",25.0);
		SearsIncomeMap.put("60-100",20.0);
		
		WebMDAgeMap.put("18-24",9.2);
		WebMDAgeMap.put("25-34",15.1);
		WebMDAgeMap.put("35-44",15.7);
		WebMDAgeMap.put("45-54",19.4);
		WebMDAgeMap.put("55-64",18.4);
		WebMDIncomeMap.put("0-30",46.0);
		WebMDIncomeMap.put("36-60",26.5);
		WebMDIncomeMap.put("60-100",18.5);
		
		EhowAgeMap.put("18-24",10.2);
		EhowAgeMap.put("25-34",15.1);
		EhowAgeMap.put("35-44",15.7);
		EhowAgeMap.put("45-54",19.4);
		EhowAgeMap.put("55-64",17.4);
		EhowIncomeMap.put("0-30",50.0);
		EhowIncomeMap.put("36-60",27.0);
		EhowIncomeMap.put("60-100",15.0);
		
		AskAgeMap.put("18-24",10.2);
		AskAgeMap.put("25-34",13.1);
		AskAgeMap.put("35-44",15.7);
		AskAgeMap.put("45-54",20.4);
		AskAgeMap.put("55-64",18.4);
		AskIncomeMap.put("0-30",50.0);
		AskIncomeMap.put("36-60",28.0);
		AskIncomeMap.put("60-100",15.0);
		
		TripAdvisorAgeMap.put("18-24",8.2);
		TripAdvisorAgeMap.put("25-34",16.1);
		TripAdvisorAgeMap.put("35-44",17.7);
		TripAdvisorAgeMap.put("45-54",20.4);
		TripAdvisorAgeMap.put("55-64",17.4);
		TripAdvisorIncomeMap.put("0-30",46.5);
		TripAdvisorIncomeMap.put("36-60",26.0);
		TripAdvisorIncomeMap.put("60-100",17.5);
		
		CNetAgeMap.put("18-24",12.2);
		CNetAgeMap.put("25-34",15.1);
		CNetAgeMap.put("35-44",15.7);
		CNetAgeMap.put("45-54",18.4);
		CNetAgeMap.put("55-64",17.4);
		CNetIncomeMap.put("0-30",48.0);
		CNetIncomeMap.put("36-60",26.5);
		CNetIncomeMap.put("60-100",16.5);
		
		WeatherAgeMap.put("18-24",9.2);
		WeatherAgeMap.put("25-34",15.1);
		WeatherAgeMap.put("35-44",16.7);
		WeatherAgeMap.put("45-54",20.4);
		WeatherAgeMap.put("55-64",18.4);
		WeatherIncomeMap.put("0-30",45.5);
		WeatherIncomeMap.put("36-60",26.5);
		WeatherIncomeMap.put("60-100",18.5);
		
		
		WebSites.put("Yahoo",new WebSite("Yahoo",16.0,YahooAgeMap,YahooIncomeMap,49.6,26.0));
		WebSites.put("CNN",new WebSite("CNN",2.2,CNNAgeMap,CNNIncomeMap,48.6,24));
		WebSites.put("NY Times",new WebSite("NY Times",3.1,NYTimesAgeMap,NYTimesIncomeMap,47.6,23));
		WebSites.put("Hfngtn",new WebSite("Hfngtn",8.1,HfngtnAgeMap,HfngtnIncomeMap,46.6,22));
		WebSites.put("MSN",new WebSite("MSN",18.2,MSNAgeMap,MSNIncomeMap,47.6,25));
		WebSites.put("Fox",new WebSite("Fox",3.1,FoxAgeMap,FoxIncomeMap,48.6,24));
		WebSites.put("Amazon",new WebSite("Amazon",12.8,AmazonAgeMap,AmazonIncomeMap,47.6,21));
		WebSites.put("Ebay",new WebSite("Ebay",8.5,EbayAgeMap,EbayIncomeMap,48.6,22));
		WebSites.put("Wal-Mart",new WebSite("Wal-Mart",3.8,WalMartAgeMap,WalMartIncomeMap,45.6,18));
		WebSites.put("Target",new WebSite("Target",2.0,TargetAgeMap,TargetIncomeMap,45.6,19));
		WebSites.put("BestBuy",new WebSite("BestBuy",1.6,BestBuyAgeMap,BestBuyIncomeMap,47.6,20));
		WebSites.put("Sears",new WebSite("Sears",1.6,SearsAgeMap,SearsIncomeMap,46.6,19));
		WebSites.put("WebMD",new WebSite("WebMD",2.5,WebMDAgeMap,WebMDIncomeMap,45.6,24));
		WebSites.put("Ehow",new WebSite("Ehow",2.5,EhowAgeMap,EhowIncomeMap,47.6,28));
		WebSites.put("Ask",new WebSite("Ask",5.0,AskAgeMap,AskIncomeMap,48.6,28));
		WebSites.put("TripAdvisor",new WebSite("TripAdvisor",1.6,TripAdvisorAgeMap,TripAdvisorIncomeMap,46.6,30));
		WebSites.put("CNet",new WebSite("CNet",1.7,CNetAgeMap,CNetIncomeMap,50.6,27));
		WebSites.put("Weather",new WebSite("Weather",5.8,WeatherAgeMap,WeatherIncomeMap,47.6,31));
	}
	
*/	
	
}



